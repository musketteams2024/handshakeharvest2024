#!/bin/bash
#
# #--------------------------------------------------------------------------------------------------------------------#
#
#
# Copyright (C) 2024  Musketteams
#
# This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public 
# License as published by the Free Software Foundation; either version 2 of the License, or any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
# You should have received a copy of the GNU General Public License along with this program; if not, write to the
# Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
# #--------------------------------------------------------------------------------------------------------------------#
#197 completed on
# Disclaimer:   This script is intended for use only for private study or during an authorised pentest. The author bears no responsibility for malicious or illegal use.


# Text color variables - saves retyping these awful ANSI codes

txtrst="\e[0m"      # Text reset
def="\e[1;34m"	    # default 		   blue
warn="\e[1;31m"     # warning		   red
info="\e[1;34m"     # info                 blue
q="\e[1;32m"	    # questions            green
inp="\e[1;36m"	    # input variables      magenta
yel="\e[1;33m"      # typed keyboard
ital="\e[3m"	    # italic
norm="\e[0m"        # normal
bold="\e[1m"        # bold
undr="\e[4m"       # underline
#  ANSI coding all thanks to Vulpi author of Pwnstar9.0


ERASJOHN_fn()

{

clear

if [[ $(ls -A /root/HANDSHAKEHOLD/*rec) ]]; then

      NOTEMPT=1

	fi

if [[ $NOTEMPT == 1 ]]; then

echo ""
echo ""    
echo -e "$warn         !!!!The$yel /root/HANDSHAKEHOLD/$warn directory may contain old John restore files.!!!!$txtrst" 

until  [[ $ERASTEST == y || $ERASTEST == Y ]]; do
  
echo -e "$txtrst"
echo -e "$q  Do you wish to erase all old John.rec restore files from this  directory?"
echo -e "$info     Leaving these files in place will not affect the program."
echo "" 
echo -e "$inp  Type$yel(y/Y)$inp to erase these files or$yel(n/N)$inp to $txtrst"
echo -e "$inp    leave these files in place.$txtrst"
read ERAS

	while true
	do

echo ""
echo -e "$inp  You entered$yel $ERAS$info type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read ERASTEST

	case $ERASTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e "$warn  !!!Wrong input try again!!!$txtrst"

	done
		done
			fi


	if [[ $ERAS == y || $ERAS == Y ]]; then

           rm -f /root/HANDSHAKEHOLD/*.rec 

                       fi

}



exit_fn()

{

echo -e "$txtrst"
		rm -f /tmp/HANDTEST/DICLIST.txt
		rm -f /tmp/aircrackout.txt
		rm -f /tmp/LNE2CRK.txt
                rm -f /tmp/airfile.txt

#echo -e "[+]  Restoring Network Manager functions"
#	sleep 3

#	service network-manager restart 2> /dev/null > /dev/null
#	sleep 1
#	service NetworkManager restart 2> /dev/null > /dev/null
#	sleep 1
#	service avahi-daemon restart 2> /dev/null > /dev/null
#	echo ""f
#	echo -e "[+]  If wifi functions are NOT shortly restored?."
#	echo -e "[+]  Suggest you reboot the computer before proceeding." 
	sleep 1
        echo ""
        echo -e "[+]  May the password be with you!"
	echo -e ""
	echo -e "[+]  Happy Trails From Musket Teams."
	echo ""
	echo ""
	sleep 5
	exit 0
}

trap exit_fn INT # trap exit

MKDIR_fn()

{

if [[ ! -d "/tmp/HANDTEST" ]]; then

	mkdir -p -m 700 "/tmp/HANDTEST";

	fi

#Make dir to hold tested handshakes

if [[ ! -d "/root/HANDSHAKEHOLD" ]]; then

	mkdir -p -m 700 "/root/HANDSHAKEHOLD";

	fi

if [[ ! -d "/root/PROBEESSID_DATA" ]]; then

	mkdir -p -m 700 "/root/PROBEESSID_DATA";

	fi

if [[ ! -f "touch /root/HANDSHAKEHOLD/Multiattacklogfile.txt" ]]; then #3

		touch /root/HANDSHAKEHOLD/Multiattacklogfile.txt

	fi

}

#Start Program

# Make directories

MKDIR_fn

clear

STARTPAGE_fn()

{
echo ""
echo -e "$yel                   *******************************************"
echo -e "$yel                   *$info Musket Team WPA Multi.cap Cracking Tool$yel *"
echo -e "$yel                   *******************************************"
echo ""
echo -e "$info                  In Memory of Station Hypo(FRUPAC) Hawaii 1942"
echo -e "$info                              ALL THANKS to: Jintanaa"
echo -e ""  
echo -e "$info              This program was tested in Musket Teams Operational Areas"
echo -e "$info              using Kali 2024.1. It can automatically attack lists of"
echo -e "$info              cap files looking WPA PSK."
echo -e ""
echo -e "$warn              This program can only use cap files obtained thru."
echo -e "$warn              handshakeharvest2024-1."
 
echo -e "$info              Cap files obtained from other sources can be used if the"
echo -e "$info              file is renamed with the bssid of the target then a dash"
echo -e "$info              then the essid.cap see readme."
echo -e "$info                          Example 00:11:22:33:44:55-MYWIFI.cap"
echo -e "$warn              The only dash in the file name is between ESSID and BSSID."
echo -e "$warn              All other dash (-) in ESSID must be removed."
 
echo -e "$inp              Place any cap files named as shown above in the"
echo -e "$yel              /root/HANDSHAKEHOLD$inp folder. Place dictionary or word"
echo -e "$inp              lists to be tested in the$yel /root/PROBEESSID_DATA/$inp folder."
echo -e ""

while true

do
echo -e "$inp                              Press $yel(y/Y)$inp to continue...."
echo -e "         Press $yel(n/N)$inp to abort!!..Press any other key to try again:"
echo -e "$txtrst"

  read -p "   Enter: " CONFIRM

  case $CONFIRM in
    y|Y|YES|yes|Yes) break ;;
    n|N|no|NO|No)
      echo Aborting - you entered $CONFIRM
      exit
      ;;

	  esac

		done

echo -e "$info  You entered $CONFIRM.  Continuing ...$txtrst"
sleep 3

NOCAP=$(ls -A /root/HANDSHAKEHOLD/*.cap 2>/dev/null)


#If HANDSHAKEHOLD OR Probe empty warn and return to start page 

    if [[ -z $NOCAP ]]; then

		echo -e ""
		echo -e "$warn  No cap files found in the$yel /root/HANDSHAKEHOLD$warn folder"
		echo -e ""
		echo -e "$info  Place files in the /root/HANDSHAKEHOLD folder before proceeding!!!"
	   	echo -e ""
           	sleep 3
		STARTPAGE_fn

		fi

NOWORD=$(ls -A /root/PROBEESSID_DATA/ 2>/dev/null)


    if [[ -z "$NOWORD" ]]; then

		echo -e ""
		echo -e "$warn  No files found in the$yel /root/PROBEESSID_DATA/$warn folder"
                echo -e ""   
	        echo -e "$info  Place your Wordlist files in the /root/PROBEESSID_DATA/ folder before proceeding!!!"
		echo -e ""		
		sleep 3
		STARTPAGE_fn

		fi

}

STARTPAGE_fn

ERASJOHN_fn


clear

rm -f /tmp/HANDTEST/DICLIST.txt


CAPFILE_fn()

{

###Select cap files to cracked

	until  [[ $WEAKCANTEST == y || $WEAKCANTEST == Y ]]; do

    	ls -A /root/HANDSHAKEHOLD/*.cap | awk -F "/" '{$1=$2=$3=""; print $0}' | tee > /tmp/HANDTEST/CAP.txt

echo -e ""
echo -e "$info$bold            $undr CAP FILE(s) to be Attacked $txtrst"
echo ""
echo ""
echo -e "$info     Place your .cap files in the$yel /root/HANDSHAKEHOLD/"
echo -e "$info  folder before continuing....."
echo ""
echo -e "         You can attack a single cap file, attack ALL files in"
echo -e "       the /root/HANDSHAKEHOLD/ folder or start the attack from a"
echo -e "       a specific position in the files listed."
echo -e "$info  Consult the$yel /root/HANDSHAKEHOLD/Multiattacklog$info file for."
echo -e "$info  attacks previously conducted."

echo -e ""
echo -e "$inp      Select$yel (1)$inp to attack all cap files in the folder."
echo -e "$inp      Select$yel (2)$inp to attack cap files starting from a position."
echo -e "$inp      Select$yel (3)$inp to attack a single cap file"
echo -e "$inp       in the /root/HANDSHAKEHOLD/ folder."
echo -e "$txtrst"

	read  -p "   Enter: " ATTKSEQ

	while true
	do

	echo ""
	echo -e  "$inp      You entered$yel $ATTKSEQ$inp,  select$yel (y/Y)$inp to continue."
	echo -e  "$inp  Select$yel (n/N)$inp to try again.$txtrst"
	echo -e "$txtrst"

	read -p "   Confirm Entry: " WEAKCANTEST

	case $WEAKCANTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

	clear

                  if [[ $ATTKSEQ != 1 ]] && [[ $ATTKSEQ != 2 ]] && [[ $ATTKSEQ != 3 ]]; then
                           echo ""
                           echo -e  "$warn!!!  Enter$yel 1$warn,$yel 2$warn,$yel 3$warn,ONLY!!!"
                           echo ""
                           sleep 3

				CAPFILE_fn

				fi

		done

}
        
CAPFILE_fn


			if [[ $ATTKSEQ == 1 ]]; then

    	ls -A /root/HANDSHAKEHOLD/*.cap | awk -F "/" '{$1=$2=$3=""; print $0}' | tee > /tmp/HANDTEST/CAP.txt

     		echo ""
		echo -e "$info  Attacking all files in the$yel /root/HANDSHAKEHOLD/$info folder."   
                echo -e "  Continuing................"
                echo ""
		sleep 3

         			fi  #ATTKSEQ == 1

			if [[ $ATTKSEQ == 2 ]]; then

			until  [[ $ATTKSEQ2TEST == y || $ATTKSEQ2TEST == Y ]]; do

    	ls -A /root/HANDSHAKEHOLD/*.cap | awk -F "/" '{$1=$2=$3=""; print $0}' | tee > /tmp/HANDTEST/CAP.txt

		sleep 2
			echo ""
			echo -e "$info  $txtrst"
			echo -e ""
			echo -e "$info  Enter the line number of the cap file you wish to begin"
			echo -e "$info  testing from. Program will then test all files FOUND" 
			echo -e "$info  in the /root/HANDSHAKEHOLD folder from that point on."
                         echo -e "$info  This faciltiy allows the user to stop a test and restart."
			echo -e "$info  Consult the$yel /root/HANDSHAKEHOLD/Multiattacklog$info file for."
                         echo -e "$info  attacks previously conducted."

			echo -e "$txtrst"

				CAPLIST=$(cat /tmp/HANDTEST/CAP.txt | nl -ba -w 1  -s ': ')

			echo ""
			echo -e "$info Files found in the /root/HANDSHAKEHOLD/ folder.$txtrst"
			echo ""
			echo "$CAPLIST" | sed 's/^/       /'
			echo ""
			echo ""

			echo -e "$q    What cap file do you wish to start testing from?"
			echo ""
			echo -e "$info     If your file is not listed then load the file to"
			echo -e "  the$yel /root/HANDSHAKEHOLD/$info folder, press any of the line"
			echo -e "  numbers seen. When prompted for confirmation select$yel n/N$info and"
			echo -e "  a new file list will be generated."

			echo -e "$txtrst"
			echo ""
			read  -p "   Enter Line Number Here: " grep_Line_Number
			LNE2CNT=$grep_Line_Number


			CAP2USE=$(cat /tmp/HANDTEST/CAP.txt | sed -n ""$grep_Line_Number"p")

			# Remove trailing white spaces leaves spaces between names intact

			CAP2USE=$(echo $CAP2USE | xargs)

			rm -f /tmp/HANDTEST/CAP.txt

			while true
			do

			echo ""
			echo -e  "$inp      You entered$yel $CAP2USE$inp, select$yel (y/Y)$inp to continue."
			echo -e  "$inp  Select$yel (n/N)$inp to try again.$txtrst"
			echo -e "$txtrst"

			read -p "   Confirm Entry: " ATTKSEQ2TEST

			case $ATTKSEQ2TEST in
			y|Y|n|N) break ;;
			~|~~)
			echo Aborting -
			exit
			;;
			esac
			echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

			done

			clear

			done  #until  [[ $ATTKSEQ2TEST

			fi    # ATTKSEQ == 2

			if [[ $ATTKSEQ == 3 ]]; then

			until  [[ $ATTKSEQ3TEST == y || $ATTKSEQ3TEST == Y ]]; do

    	ls -A /root/HANDSHAKEHOLD/*.cap | awk -F "/" '{$1=$2=$3=""; print $0}' | tee > /tmp/HANDTEST/CAP.txt

			echo ""
			echo -e "$info  $txtrst"
			echo -e ""
			echo -e "$info  Enter the line number of the cap file you wish test."
			echo -e "$info  Program will test only that one(1) file." 
			echo -e "$info  Consult the$yel /root/HANDSHAKEHOLD/Multiattacklog$info file for."
                        echo -e "$info  attacks conducted."

			echo -e "$txtrst"

				CAPLIST=$(cat /tmp/HANDTEST/CAP.txt | nl -ba -w 1  -s ': ')

			echo ""
			echo -e "$info Files found in the /root/HANDSHAKEHOLD/ folder.$txtrst"
			echo ""
			echo "$CAPLIST" | sed 's/^/       /'
			#echo CAP2LNE=$(echo "$CAPLIST" | awk -F " " '{$1=""; PRINT $0}'
			#LNE2CRK=$(echo "$CAPLIST" | sed 's/://' | awk '{ print $1}')
			echo ""
			echo ""

			echo -e "$q    What cap file do you wish to start testing from?"
			echo ""
			echo -e "$info     If your file is not listed then load the file to"
			echo -e "  the$yel /root/HANDSHAKEHOLD/$info folder, press any of the line"
			echo -e "  numbers seen. When prompted for confirmation select$yel n/N$info and"
			echo -e "  a new file list will be generated."

			echo -e "$txtrst"
			echo ""
			read  -p "   Enter Line Number Here: " grep_Line_Number

			LNE2CNT=$grep_Line_Number

			CAP2USE=$(cat /tmp/HANDTEST/CAP.txt | sed -n ""$grep_Line_Number"p")

			# Remove trailing white spaces leaves spaces between names intact

			CAP2USE=$(echo $CAP2USE | xargs)
                        
			rm -f /tmp/HANDTEST/CAP.txt

			while true
			do

			echo ""
			echo -e  "$inp      You entered$yel $CAP2USE$inp,  select$yel (y/Y)$inp to continue."
			echo -e  "$inp  Select$yel (n/N)$inp to try again.$txtrst"
			echo -e "$txtrst"

			read -p "   Confirm Entry: " ATTKSEQ3TEST

			case $ATTKSEQ3TEST in
			y|Y|n|N) break ;;
			~|~~)
			echo Aborting -
			exit
			;;

			esac
			echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

			done

			clear

			done  #until  [[ $ATTKSEQ3TEST

			fi    # ATTKSEQ == 3

##########Select cap file End##################

	until  [[ $WEAKCAN4TEST == y ]] || [[ $WEAKCAN4TEST == Y ]]; do

	ls -A /root/PROBEESSID_DATA/ | tee > /tmp/HANDTEST/DICLIST.txt

        echo -e "$info$bold  $undr Dictionary - Wordlist Selection $txtrst"
	echo ""
	echo -e "$info     Enter the Word List to be used with Aircrack-ng"
	echo -e "$info  File must be placed in the /root/PROBEESSID_DATA/ folder ONLY!!!" 
	echo -e "$txtrst"


#ls -A /root/PROBEESSID_DATA/ | awk -F "/" '{$1=$2=$3=""; print $0}' | tee > /tmp/HANDTEST/DICLIST.txt

#Select Dictionary#

DICLIST=$(cat /tmp/HANDTEST/DICLIST.txt | nl -ba -w 1  -s ': ')

echo ""
echo -e "$info Files found in the /root/PROBEESSID_DATA/ folder.$txtrst"
echo " "
echo "$DICLIST" | sed 's/^/       /'
echo ""
echo ""

echo -e "$q    What Wordlist file do you wish use?"
echo ""
echo -e "$info     If your file is not listed then copy the file to"
echo -e "  the$yel /root/PROBEESSID_DATA/$info folder, press any of the line"
echo -e "  numbers seen. When prompted for confirmation select$yel n/N$info and"
echo -e "  a new file list will be generated with the new file listed."
echo -e ""
echo -e "$warn     If you select a large wordlist, the program may take a while"
echo -e "$warn  to process the file so standby...."

echo -e "$txtrst"
echo ""
read  -p "   Enter Line Number Here: " grep_Line_Number

DIC2USE=$(cat /tmp/HANDTEST/DICLIST.txt | sed -n ""$grep_Line_Number"p")

# Remove trailing white spaces leaves spaces between names intact

DIC2USE=$(echo $DIC2USE | xargs)
DICLEN=$(cat < /root/PROBEESSID_DATA/$DIC2USE | sed -n \$=)


rm -f /tmp/HANDTEST/DICLIST.txt

###############

	while true
	do

	echo ""
	echo -e  "$inp      You entered$yel $DIC2USE$inp, which has$yel $DICLEN$inp keys"
	echo -e  "$inp   to check. Select$yel (y/Y)$inp to continue or$yel (n/N)$inp to try again.$txtrst"
	echo -e "$txtrst"

	read -p "   Confirm Entry: " WEAKCAN4TEST

	case $WEAKCAN4TEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

	clear

		done

##########Select Dictionary End##################


#ls -A /root/PROBEESSID_DATA/ | awk -F "/" '{$1=$2=$3=""; print $0}' | tee > /tmp/HANDTEST/DICLIST.txt

#DICLIST=$(cat /tmp/HANDTEST/DICLIST.txt | sed 's/^/       /'

ls -A /root/HANDSHAKEHOLD/*.cap | awk -F "/" '{$1=$2=$3=""; print $0}'| sed 's/^[ \t]*//;s/[ \t]*$//' | tee > /tmp/airfile.txt

#Print list of files to a text files

#Assign lines to count
#Dictionary Modules selection
#DIC2USE=essidprobesdic2.txt


		if [[ $ATTKSEQ == 1 ]]; then


			LNE2CNT=1

				fi

#debug Continue from last attack
#Remove below Add module to restart from spot
#Add log file of processed data

#Previous Stop Point
#LNE2CNT=112

#Count the number of lines in the file

TOTLNECNT=$(cat < /tmp/airfile.txt | sed -n \$=)

		if [[ $ATTKSEQ == 2 ]]; then 

			TOTLNECNT=$(expr "$TOTLNECNT" - $LNE2CNT) 
			TOTLNECNT=$(expr "$TOTLNECNT" + 1)

				fi

	until [ $TOTLNECNT == 0 ]; do

                #Prints a specific numbered single line Lots of ways to do this

                cat < /tmp/airfile.txt | awk -v LINE="$LNE2CNT" 'NR == LINE' > /tmp/LNE2CRK.txt

		sleep 2

		LNE2CRK=$(cat < /tmp/LNE2CRK.txt | sed 's/^[ \t]*//;s/[ \t]*$//')

		sleep 2

                # sed 's/^[ \t]*//;s/[ \t]*$//' Remove white spaces from variable

		BSSID=$(cat < /tmp/LNE2CRK.txt | awk -F "-" '{print $1}' | sed 's/^[ \t]*//;s/[ \t]*$//')

		ESSID=$(cat < /tmp/LNE2CRK.txt | awk -F "-" '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')

#echo $LNE2CRK
#echo ${#LNE2CRK}
#echo "LNE2CRK above"
#echo $BSSID
#echo ${#BSSID}
#echo "BSSID above"
#echo $ESSID
#echo ${#ESSID}
#echo "ESSID above"
#echo $DIC2USE
#echo ${#DIC2USE}
#echo "Dictionary"

echo "[+]"
echo "[+]  File to crack; $LNE2CRK"
echo "[+]  Using $DIC2USE word list."
echo "[+]  Wordlist has $DICLEN keys to process."

	if [[ $ATTKSEQ == 1 || $ATTKSEQ == 2 ]]; then

echo "[+]  Number of files remaining = $TOTLNECNT"

                fi

sleep 5

############Start of of aircrack cycle##########

		if [[ ${#BSSID} == 17 ]]; then #5

DATELOGSTAR=$(date +%y%m%d-%H:%M)

echo -e "[+]"
echo -e "[+]  Starting attack against Line$LNE2CNT $BSSID"
echo -e "[+]  If this attack is terminated before completion it can be continued"  
echo -e "[+]  from termination point using a terminal window"
echo -e "[+]  see /HANDSHAKEHOLD/Multiattacklogfile.txt for details."

echo "Line No=$LNE2CNT" >> /root/HANDSHAKEHOLD/Multiattacklogfile.txt
echo "Line-No=$LNE2CNT Starting attack against Line-No=$LNE2CNT-$LNE2CRK-$DIC2USE-$DATELOGSTAR"  >>  /root/HANDSHAKEHOLD/Multiattacklogfile.txt
echo "If uncompleted enter john --restore=/root/HANDSHAKEHOLD/JOHN-RESTORE-$BSSID-$DATELOGSTAR  | aircrack-ng HANDSHAKEHOLD/$LNE2CRK -b "$BSSID" -w -" >>  /root/HANDSHAKEHOLD/Multiattacklogfile.txt

xterm -g 95x30-1+150 -T "Aircrack-ng  $LNE2CRK" -e "john --session=/root/HANDSHAKEHOLD/JOHN-RESTORE-$BSSID-$DATELOGSTAR --wordlist=/root/PROBEESSID_DATA/$DIC2USE --stdout | aircrack-ng HANDSHAKEHOLD/$LNE2CRK -b "$BSSID" -w - | tee /tmp/aircrackout.txt"; sleep 10  &

#xterm -g 95x30-1+200 -T "Aircrack-ng $LNE2CRK" -e "aircrack-ng HANDSHAKEHOLD/$LNE2CRK -b "$BSSID" -w PROBEESSID_DATA/$DIC2USE | tee /tmp/aircrackout.txt"; sleep 5  &
      
# Looking for WPA key in aircrack output from tee

#"An ESSID is required"

ESSIDRQR=$(cat < /tmp/aircrackout.txt | grep "An ESSID is required")

sleep .01

#NOHAND=$(cat < /tmp/aircrackout.txt | grep "WPA (0 handshake)")

#sleep .01

#NONET=$(cat < /tmp/aircrackout.txt | grep "No networks found, exiting")

#sleep .01
             
KEYFND=$(cat -v < /tmp/aircrackout.txt | grep "FOUND!" |  awk 'NR == 2' |sed 's/[[]//g' | sed 's/[]]//g' | sed 's/^//g' | sed -n 's/^.*FOUND!/FOUND!/p')

sleep 3

#Strip the long aircrack variable to get the time block

#RUNTME1=$(cat < /tmp/aircrackout.txt | grep "keys tested" | awk '{print $1}' | xargs)

cat < /tmp/aircrackout.txt | grep "keys tested" | awk '{print $1}' | sed 's/^[ \t]*//' | tail -1 | grep -o '\[[^][]*]' > /tmp/RUNTME1.txt


#  tail -1  Capture last line of text file
#  grep -o '\[[^][]*]' capture data betrween brackets
#  sed 's/^[ \t]*//'  remove blanks


# echo ${RUNTME1: (-10)} > /tmp/RUNTME1.txt

sleep 3

#RUNTME=$(cat < /tmp/RUNTME.txt | sed 's/:/./' | sed 's/:/./')

RUNTME=$(cat < /tmp/RUNTME1.txt)

				fi

sleep 3
ENDPROS=1


                if [[ -z $ESSIDRQR ]]; then
		
                        ENDPROS=0

			else 

			echo -e  "[+]  Skipping file $LNE2CRK - No essid available."
  
                        echo "Line-No=$LNE2CNT-Skipping $LNE2CRK No essid available" >> /root/HANDSHAKEHOLD/Multiattacklogfile.txt

                        echo "Start=$DATELOGSTAR-End=$DATELOGEND" >> /root/HANDSHAKEHOLD/Multiattacklogfile.txt

			 fi

            if [[ $ENDPROS == 0 ]]; then


		if [[ -z "$KEYFND" ]]; then
             
			echo "[+]  No WPA Key found in $LNE2CRK." 

                        echo "[+]  Time-Required=$RUNTME-Wordlist-Length=$DICLEN."

			DATELOGEND=$(date +%y%m%d-%H:%M)

        echo "Line-No=$LNE2CNT-$LNE2CRK-$DIC2USE-No-WPA-Key-found" >>  /root/HANDSHAKEHOLD/Multiattacklogfile.txt
 
        echo "Time-Required=$RUNTME-Wordlist-Length=$DICLEN-Start=$DATELOGSTAR-End=$DATELOGEND"  >>  /root/HANDSHAKEHOLD/Multiattacklogfile.txt

         else 

echo "[+]  A WPA PSK Code has been FOUND! in /root/HANDSHAKEHOLD/$LINE2CRK cap file for"

echo "[+]  $BSSID-$ESSID. Time to process was $RUNTME, Wordlist-Length=$DICLEN."

echo "[+]  Copying a .txt file to the /root/HANDSHAKEHOLD folder with the WPA PSK Code FOUND"
      

	 	if [[ ! -f "touch /root/HANDSHAKEHOLD/$BSSID-$ESSID-WPA-Key-Found.txt" ]]; then #2

		touch /root/HANDSHAKEHOLD/$BSSID-$ESSID-WPA-Key-Found.txt

		sleep 1

				    fi #2

		echo "$BSSID-$ESSID-WPA_$KEYFND" > /root/HANDSHAKEHOLD/$BSSID-$ESSID-WPA-Key-Found.txt

	sleep 1

		echo "$BSSID-$ESSID-WPA_$KEYFND" >> /root/HANDSHAKEHOLD/$BSSID-$ESSID-WPA-Key-Found.txt

                DATELOGEND=$(date +%y%m%d-%H:%M)

	         echo "Line-No=$LNE2CNT-$LNE2CRK-$DIC2USE-WPA-Key-$KEYFND" >>  /root/HANDSHAKEHOLD/Multiattacklogfile.txt
                 echo "Time Required=$RUNTME-Wordlist-Length=$DICLEN-Started-on-$DATELOGSTAR-Completed-on-$DATELOGEND"  >>  /root/HANDSHAKEHOLD/Multiattacklogfile.txt
sleep 3

                fi

                fi #[[ $ENDPROS == "0" ]]; then

 
                     if [[ ${#BSSID} != 17 ]]; then #5

                        DATELOGEND=$(date +%y%m%d-%H:%M)

			echo -e  "[+]  Skipping file $LNE2CRK - File name not in proper format see readme for program."
  
                        echo "Line-No=$LNE2CNT-Skipping $LNE2CRK File name not in proper format see readme file-Time-Start=$DATELOGSTAR" >> /root/HANDSHAKEHOLD/Multiattacklogfile.txt
			echo "Line-No=$LNE2CNT-Rename file with bssid-essid.cap example 00:11:22:33:44:55-Mywifi.cap" >> /root/HANDSHAKEHOLD/Multiattacklogfile.txt

				fi

		echo "[+]  Attack-on-$LNE2CRK-Completed"
		echo "Line-No=$LNE2CNT-Attack-on-$LNE2CRK-Completed" >>  /root/HANDSHAKEHOLD/Multiattacklogfile.txt

############End of aircrack cycle##########

		rm -f /tmp/aircrackout.txt
		rm -f /tmp/LNE2CRK.txt
		rm -f /root/HANDSHAKEHOLD/JOHN-RESTORE-$BSSID-$DATELOGSTAR.rec

		if [[ $ATTKSEQ == 1 || $ATTKSEQ == 2 ]]; then 

			LNE2CNT=$(expr "$LNE2CNT" + 1)

			TOTLNECNT=$(expr "$TOTLNECNT" - 1) 

				fi

		if [[ $ATTKSEQ == 3  ]]; then 

			TOTLNECNT=0

		echo -e "[+]  Only one .cap file selected."
		echo -e "[+]  Program is ending....."

			exit_fn

				fi

		if [[ TOTLNECNT == 0 ]]; then
			
				exit_fn			

				fi
			
killall -q aircrack-ng &>dev\null
killall -q tee &>dev\null
killall -q cat &>dev\null
killall -q xterm &>dev\null

done

	killall -q aircrack-ng &>dev\null
	killall -q tee &>dev\null
	killall -q cat &>dev\null
	killall -q xterm &>dev\null
	rm -f /tmp/airfile.txt

#junk

#cat < aircrackout.txt | grep "KEY NOT FOUND"
#root@kali:~# KNF=$(cat < /tmp/aircrackout.txt | grep "KEY NOT FOUND")


#FC:7C:02:6A:B9:14-ROOM_11A_WPA_1_handshake.cap
#FOUND!
#cat -v < /tmp/aircrackout.txt | grep "FOUND!" | sed 's/[[]//g' | sed 's/[]]//g' > /tmp/keyfound.txt
#cat -v < /tmp/aircrackout.txt | grep "FOUND!" |  awk 'NR == 2' |sed 's/[[]//g' | sed 's/[]]//g' | sed 's/^//g' | sed -n 's/^.*FOUND!/FOUND!/p' > /tmp/keyfound.txt
