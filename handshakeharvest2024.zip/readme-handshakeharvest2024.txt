            

Introduction to handshakeharvest2024.zip package

   The following program handshakeharvest2024.zip has been released for community use.

   This program package attempts to collect WPA handshakes for ALL networks seen in the reception area automatically and has been tested for years. This newer version corrects bugs found and takes advantage of lessons learned.

   Since the days of Bletchley Park and Enigma during World War 2, it has long been known that operator error and weak encryption can lead to the system being compromised. Enigma was initially cracked when an German operator did not follow instructions and sent the same key twice. As for WIFI WPA encryption, during the years the WPS system was vulnerable thru reaver, a general glimpse of how users select passwords was obtained.

   If you are in an area where many WIFI networks exist, those with weak passwords are vulnerable and there will always be weak passwords in some of these networks. The problem is finding those with these weak pass phrases, as collecting a large number of handshakes and then processing them takes time. Furthermore attempting to crack all these handshakes thru brute force can be labor intensive. Even using high speed computers with graphics cards, it can take a long time. This package approaches the WPA cracking problem differently. Instead of focusing on one handshake and large wordlist files, the program collects many handshakes and then tests them all with smaller common passwords files looking for weak encryption and common pass phrases.

   The handshake harvest program can collect a large number of handshakes automatically and is literally fire and forget. Start the program, go thru the simple setup and walk away. In our areas off operation, within 24 hours many many handshakes are ALAWAYS collected.  These handshakes now need to be tested. An auxiliary program airmulticrack2024-2.sh is also found in the handshakeharvest2024 zip file. Run the program airmulticrack2024-2.sh, select the password list to test, and ALL handshakes in the /root/HANDSHAKEHOLD/ folder  will be tested against the wordlist chosen automatically. Passwords found are stored in a text file easily referenced.

   Many times the WPA pass phrase is transmitted in clear text which can be collected. Users have also been seen to either use the ESSID as the WPA pass phrase or the 8 digit WPS Pin. The hanshakeharvest program collects these possible passwords transmitted in the clear and stores them in a password file. The ESSID of all networks seen is also added during each scan cycle.

   The tools in this program package reduces the labor and time required to collect and process WPA handshakes and is well suited for slower laptops and computers.

   The handshakeharvest-2024.zip file contains:

      handshakeharvest2024-1.sh
      airmulticrack2024-2.sH 
      readme-hanshakeharvest2024

   This is just an introduction. See the help file in the zip file entitled readme-hanshakeharvest2024 for details

@@@@@@@@@@@@@@@@@@@@@@@@

   The contents of this zip package were tested in a freshly installed Kalilinux 2024.1 hard drive install.

   First update and upgrade your kalilinux

      apt-get update

      apt-get upgrade

   To get the program to function several dependencies are required

      Install xterm

         apt-get install xterm

      Install rename

         apt-get install rename

   This program requires hcxdumptool but read below.

   WARNING DO NOT LOAD the latest version of hcxdumptool from kali as the weakcandidate command has been removed. Only two older versions work with handshakeharvest2024-1.sh

      hcxdumptool-6.2.6
      hcxdumptool-6.2.7

   Musketteams tested hcxdumptool-6.2.6.zip version extensively and loaded hcxdumptool-6.2.7.zip, which also functioned but NOT extensively tested. Versions hcxdumptool-6.2.8 and above do not work with handshakeharvest2024-1.sh.

   Download versions hcxdumptool-6.2.6 or hcxdumptool-6.2.7 from the internet, the addresses are listed below.

   Main page

      https://github.com/ZerBea/hcxdumptool

         AGAIN DO NOT use the latest tool 

   GO HERE for older releases

      https://github.com/ZerBea/hcxdumptool/releases

   Once you unzipped the program you will find a hcxdumptool folder. Go to the README.md file and open it with a text editor like mousepad or leafpad. Go to the dependencies section.

   If you decided to use hcxdumptool-6.2.6 for example, you need to load these dependencies first. 
    
      apt-get install libcurl4-openssl-dev
      apt-get install libssl-dev

   Go to the README.md file in the hcxdumptool-6.2.6 FOLDER and follow the instructions to install the hcxdumptool.

   Place the hcxdumptool folder that was provided after unzipping in /root/

   Open a terminal, change directory cd to the hcxdumptool-6.2.6 folder.

       type

          make
          make install

   If you use hcxdumptool-6.2.7, open the README.md and you will find other dependencies. Follow the instructions.

   Once the hcxdumptool-6.2.6 or hcxdumptool-6.2.7 are installed load other dependencies.

   Open a terminal in root and install hcxtools thru Kali

      apt-get install hcxtools
  
   During the install you will get a note that the latest version of hcxdumptool will be loaded but the version hcxdumptool-6.2.6 was not replaced when Musketteams loaded hcxtools.

   Now test your hcxdumptool functionality reference the weakcandidate command

   With a functioning wifi receiver just type in a terminal in root the following:

      hcxdumptool -i wlan0 --weakcandidate=12345678

   You can run airmon-ng to find the wlan0 wlan1 etc to use. In the command line listed above wlan0 is just an example.

   You do not need to put into monitor mode for the test. You will get a warning about Network Manager but the program will run.

   If for some reason the hcxdumptool dump tool was upgraded and the above command line with weakcandidate does not run, then just reinstall version hcxdumptool-6.2.6 or hcxdumptool-6.2.7 again.

   Open a terminal in root change directory to the hcxdumptool-6.2.6 folder and type make install again.

   This did not happen with Musketteams. We did load the latest version of hcxdumptool as a test and then just manually install all the dependencies for the older version and then installed hcxdumptool-6.2.6/hcxdumptool-6.2.7 and the older version was installed and functioned fine. In this case reboot the computer before testing.

   KaliLinux Power Suggestions

   Before running handshakehold2024-1.sh or airmulticrack2024-2.sh

   Suggest you go to the Linux Setting Power Manager

     In the System drop down menu tab

      Plugged In

         System Power Saving

           When inactive for set NEVER

         Laptop Lid

            Switch off Display

      In the Display drop down menu

         Plugged in

            Display Power Management

               Put to Sleep Set NEVER
               Switch Off After Set NEVER

      In the Security drop down menu

         Light Locker

            Automatically Lock the Session Set to NEVER


Running handshakeharvest-2024-1.sh

   To run handshakeharvest-2024-1.sh first make the program executable.

   Place the program in root

   Open a terminal window in root and type

      chmod 755 handshakeharvest-2024-1.sh [ENTER]
      ./handshakeharvest-2024-1.sh [ENTER]

   The program will start 

   General Program functions

    The program installs folders in root. The main ones are /root/HANDSHAKEHOLD and /root/PROBEESSID_DATA/


   1. Setup - wifi receiver selected
   2. Scan for WPA encrypted networks seen
   3. Attacks each network found

     a. Attempts to induce a handshake thru a death of the BSSID
      if no handshake found.
     b. Attempts to induce a handshake from the three top client-networks pairs by activity if any exist.

   4. Searches files made with hcxdumptools looking for handshakes
   5. Looks for weak candidates found in the hcxdumptool output 
   6. Processes files for WPA pass phrases in clear text and writes password files
   7. Continues to next target until list completed
   8. Returns to item one and starts the process again.


     Setup Phase

        A short setup by the user is required, and once running, all operations are automatic. Several folders are made to root to store data such as HANDSHAKEHOLD PMKIDCAP, PCAPNGFILES, PROBEESSID_DATA.

      Scan phase

         The program first scans for potential WPA Encrypted Networks. Once a list of targeted networks has been acquired the program enters the Active Attack Phase.

      Active Attack Phase

         The program attacks each targeted WPA network in the list separately. Airodump-ng collects a .cap file while the hcxdumptool collects a .pcapng file. Aireplay-ng attempts to induce handshake production. A general deauth is directed at the targeted network. Later the top three(3) associated clients seen, rated by activity are also individually deauthed.

          During the deauth stage against the target, any handshakes collected by airodump-ng are stored. After all deauth operations are completed against a target, the .pcapng file produced by hcxdumptool is converted to .cap by tcpdump and then using aircrack-ng these files are harvested for handshakes and PMKID captures. Any handshakes and PMKID found are individually filed by bssid in the respective folders in root. Should the hcxdumptool find a Network using the Weak PSK Candidate, thus breaking the WPA Code, a text file is written and stored with the WPA code, bssid and essid. This process continues till the WPA Target list is exhausted.

         Passive Phase

      When the target list is completed, the program moves to the passive phase. An all channel scan by airodump-ng listening quietly collecting data for the time set by the user is followed by a hcxdumptool scan. Once the time allocated for the passive phase is completed, all data collected is again processed as indicated above. The program then starts another active scan phase and continues. During the passive phase the use of the hcxdumptool is optional as it is constantly interacting with other networks and is not passive.


   Handshakes collected are stored in a FOLDER in root:

         /root/HANDSHAKEHOLD/

   These *.cap files are stored in mac code BSSID sequence. Many times you will find that there are many duplicate handshakes under the same ESSID. Sometimes these are different ESSID and sometimes not.

      Example:

         00:11:22:33:44:55-Mywifi.cap

   Duplicate *.cap files with same ESSID

      If you have two *cap files with the same Essid but one file has the string "WPA_1_handshake" keep this file over the a *.cap without these words. Handshakes can be captured that are not based on the actual WPA pass phrase. Those files with the string WPA_1_handshake have a higher chance of being a handshake based on the actual WPA pass phrase of the network.

   To remove duplicates it is easier to rearrange the files temporarily by ESSID name. The program stored the file names in the folder so rearrangement can be done easily thru the following command.

       Open a terminal window in root

       cd HANDSHAKEHOLD

       #  The rename program must be manually installed in kaliLinux, see dependencies above.

       rename 's/^(.*)-(.*)(\..*)$/$2-$1$3/' *.cap

       The bssid will now be at the end of the file and all files can be arranged by ESSID. This will make it easier to delete duplicates.

       To remove handshakes that have no ESSID easily just type
       rm *unk*.cap

   Once you have manually removed duplicates or unwanted handshakes you MUST type the rename command AGAIN to restore the BSSID to the front of the file. Both handshakehold2024-1,sh and airmulticrack2024-2.sh look for this mac code at the front of the *.cap file name. As will be explained, airmulticrack2024-2.sh can test ALL the handshakes in the folder /root/HANDSHAKEHOLD/ automatically if the BSSID is at the beginning of the file and a dash (-) separates the BSSID and ESSID.

   WPA Codes broadcast in clear text and ESSID names used as WPA Codes stored as dictionary files

      For various reasons such as operator or software error, the WPA code is sometimes broadcast in clear text. For example the WPA pass phrase is sometimes entered in the ESSID block by the user. This is corrected by the user but the software still probes for this error. Furthermore users sometimes use the ESSID as the WPA pass phrase during setup. 

     As airodump-ng runs, data that might be WPA Pass phrases in clear text are stored in a file when the targeted BSSID is processed for handshakes and weakcandidate pass phrases. This password list of possible WPA codes in clear text can be latter tested with aircrack-ng or airmulticrack2024-2.sh.

     The handshakeharvest program writes all this possible WPA codes transmitted in clear text to the /root/PROBEESSID_DATA/ folder in the file:

      /root/PROBEESSID_DATA/essidprobesdic.txt

   It also sends ALL the ESSID Wifi network names captured during the Wifi network scan cycle to this essidprobesdic.txt file as well.

   As a side note, sometimes the eight digit WPS number is used as the WPS pass phrase.  All your handshakes should be also tested for ALL WPS codes. You can write this file manually to the following folder /root/PROBEESSID_DATA/wpscode.txt. Both airmulticrack2024-2.sh and handshakeharvest make this folder automatically when the program is run. You can manually select this pass phrase file when running airmulticrack2024-2.sh if it is placed in this named folder.

   Run to following to make a password list of all WPS pins
       
      crunch 8 8 "0123456789" > /root/PROBEESSID_DATA/wpscode.txt

Other codes seen

   Make sure a eight digit Zero 00000000 string is in your dictionary file. Musketteams have seen an abnormal number of Wifi networks using this code.

  Other dictionary files

  The handshakeharvest program removes any strings shorter then eight from the file essidprobesdic.txt and writes a file essidprobes8dic.txt to the /root/PROBEESSID_DATA folder.

  This file is rewritten new from data in the essidprobesdic.txt each cycle so DO NOT APPEND any new passwords to this file. If you wish to add passwords add them to the essidprobesdic.txt file ONLY.

  As the file essidprobesdic.txt gets large it will slow down the processing so suggest you make a hold file of data collected

  To make a new hold password file

  cat /root/PROBEESSID_DATA/essidprobesdic.txt | awk 'length > 7' | awk 'length < 65' | sort -u |  >   /root/PROBEESSID_DATA/essidprobesdic-hold.txt

  Once the essidprobesdic-hold.txt exists you can append data to this growing file: 

  cat /root/PROBEESSID_DATA/essidprobesdic.txt | awk 'length > 7' | awk 'length < 65' | sort -u | >> /root/PROBEESSID_DATA/essidprobesdic-hold.txt

  Once your hold file is made, just erase the /root/PROBEESSID_DAT/essidprobesdic.txt and the program will make another file at program start.

  Sorting and limiting your password files

  Limit the length to WPA standards

  cat passwordlist1 | awk 'length > 7' | awk 'length < 65' > passwordlist2

  You can sort and remove duplicate passwords in the wordlist files with the following command

  cat passwordlist1 | sort -u > passwordlist2

  Limit and sort a file

  cat passwordlist1 | awk 'length > 7' | awk 'length < 65' | sort -u  > passwordlist2

  There are many common password files. One good file is called rockyou. Download the file and run it thru these sort and length commands before using against WPA.

  You can mangle the file with John the Ripper. These techniques are not covered here. 

  Weak Candidate passwords

  The program allows you to employ passwords you might want to test automatically thru hcxdumptool functions. You can test only one password, or a list loaded automatically by the program, or you can write your own list. Choices are in the menu options. Any password list only works thru the list one word per cycle. A cycle is checking ALL the WPA encrypted network scanned at the start of the cycle so limit any password list you write to no more then 60 or so passwords if you have many many WPA network targets.


Airmulitcrack2024-2.sh

   An auxiliary program airmulitcrack2024-2.sh is also found in the handshakeharvest-2024.zip package. Once you have collected handshake *.cap files they need to be processed with aircrack-ng searching for passwords. 
   
To run airmulitcrack2024-2.sh

   First make the program executable.

      Place the program in root

      Open a terminal window in root and type

         chmod 755 airmulitcrack2024-2.sh [Enter]
         ./airmulitcrack2024-2.sh [Enter]

   The program will start, ask as few setup questions and check ALL *.cap files in the /root/HANDSHAKEHOLD/*.cap folder

   The program will make a file in the /root/HANDSHAKEHOLD/ folder called Multiattacklogfile.txt

      /root/HANDSHAKEHOLD/Multiattacklogfile.txt 

   All your attacks details and any passwords found will be listed in this file

    Use of other dictionary password files

    If you want to use other dictionary/password files just place them in the /root/PROBEESSID_DATA/ folder. You can select them at start.

    Use of *.cap files not collected by handshakeharvest.

       If you wish to import *.cap files not collected by handshakeharvet you must rename the file as follows to allow automatic processing.

    Manually copy the *.cap file in the /root/HANDSHAKEHOLD/ folder

    The *.cap name must be in the following sequence.

      1. The mac code bssid of the network to be checked MUST be placed at the beginning of the file name. Use colons between the hexadecimals

      2. A dash (-) MUST follow the mac code bssid
      3. Place colons between the alpha-numeric
      4. Use only capitals for the mac code Alpha numeric 
      5. Any dashes in the ESSID network name must be removed or substituted 
      6. The only dash allowed is between the BSSID and the ESSID

    Example

        Allowed

           00:11:22:33:44:55-My_wifi.cap 
     
        Not allowed
     
           00:11:22:33:44:55-My-wifi.cap

        Allowed

           0A:1B:2C:3D:4E:5F-My_wifi.cap

        Not allowed

           0a:1b:2c:3d:4e:5f-My_wifi.cap
           0a:1b:2c:3d:4e:5f-My-wifi.cap


   Passwords and details of each handshake processed are stored as text in the file below by airmulticrack2024-2.sh.

      /root/HANDSHAKEHOLD/Multiattacklogfile.txt.

   To quickly look to see if any passwords were found simply open the file and search FOUND! and any password will be seen. The length the attack took and times are also listed.

   Passwords found by weakcandidate operations thru the hcxdumptool is also sent as a text file to the /root/HANDSHAKEHOLD/ as a  *.txt file. 

Strategies

     After you terminate handshake collection thru handshakeharvest2024-1.sh, run airmulticrack2024-2.sh against the latest /root/PROBEESSID_DATA/essidprobesdic.txt file which may have captured WPA pass phrases transmitted in clear text that are associated with one of the handshakes you just captured.  

Wifi Reception.

   On clear still nights terrestrial radiation cools the air close to the ground and a temperature inversion can form close to the surface. This inversion can trap wifi signals close to the ground allowing over the horizon reception. For example in World war II the US Navy originally thought their ship to ship radio communications were secure once out of line-of-sight but soon found out otherwise, when ships many miles apart could still hear each other. They did not know then, and may even not know why today. Do not be surprised if any wifi antenna placed outside a building or structure gets many more stations at night then in the day. 

Historical Use of airmulticrck2024-1.sh

    Older versions of airmulticrack2024-2.sh have been run on a slow computer for months checking larger wordlist files against a hundred handshakes. You can stop the computer and restart just use program prompts.

    If you stop the computer a file link to continue that file processing thru aircrack-ng is found in /root/HANDSHAKEHOLD/Multiattacklogfile.txt. If you use this link the program will continue to check that one singular handshake and then stop. You can also start checking the *cap files from any *cap file stored in the HANDSHAKEHOLD folder.


Bugs

   Aircrack-ng is used to test a *.cap file for the presence of a handshake. When aircrack-ng runs it many times gives different EAPOL warnings on the screen. This dose not have any effect of the outcome, it just makes the screen messy. We have tried to suppress it but this also occurs when using a terminal thru the command line.  
   
